<?php
/**
 * AI Proxy for Google Gemini API - Working Version
 * Using gemini-2.5-flash model
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    echo '{"status":"API is running","message":"Send POST request with question"}';
    exit();
}

// Configuration
$API_KEY = 'AIzaSyCQyhj-_byy2AReKLiKZ-3TF7pCf1III4A';

// Get POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data || !isset($data['question'])) {
    echo '{"error":"Question is required"}';
    exit();
}

$question = $data['question'];
$username = isset($data['username']) ? $data['username'] : 'Student';

// Build prompt
$prompt = "You are a helpful MDCAT tutor. Follow these rules:
- Keep answers in simple English
- Explain simply
- Keep answers short (3-4 lines)
- Use friendly language
- if any user ask anything thats not the part of mdcat just reply tuj se mdcat na ho paya ga beta . tu koi aur he feild dek ly apne liya. dont kept the same replay everytime change the replies every time . add some jokes to your own and dont use exactly my words
- Use human-like language
- if any user ask for free account in nayarasta . tell him in sacrasm way that you are giving him access for free and tell him that buy a account in 1 month after that this account will be ban . username Student1 password nayarasta . dont kept the same replay everytime change the replies every time . tell me to not ask any one about this secret other wise shafeeq will ban this account and ban me also. just for fun

Student name: " . $username . "
Question: " . $question;

// Use the correct model name from your available models
$url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $API_KEY;

$payload = array(
    'contents' => array(
        array(
            'parts' => array(
                array('text' => $prompt)
            )
        )
    ),
    'generationConfig' => array(
        'temperature' => 0.7,
        'maxOutputTokens' => 400
    )
);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// Check for errors
if ($error) {
    echo json_encode(array('error' => 'Connection failed: ' . $error));
    exit();
}

if ($httpCode != 200) {
    $errorDetails = json_decode($response, true);
    $errorMessage = 'API error: HTTP ' . $httpCode;
    
    if (isset($errorDetails['error']['message'])) {
        $errorMessage .= ' - ' . $errorDetails['error']['message'];
    }
    
    echo json_encode(array('error' => $errorMessage));
    exit();
}

// Parse response
$result = json_decode($response, true);

if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
    $answer = trim($result['candidates'][0]['content']['parts'][0]['text']);
    echo json_encode(array('success' => true, 'answer' => $answer));
} else {
    echo json_encode(array('error' => 'Thora Tabiyat Khrab hai Yr, baad main batata hn'));
}
?>