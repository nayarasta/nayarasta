<?php
/**
 * Test Google Gemini API Key
 * Visit this file directly to test your API key
 */

header('Content-Type: application/json');

$API_KEY = 'AIzaSyCQyhj-_byy2AReKLiKZ-3TF7pCf1III4A';

// First, try to list available models
$listUrl = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . $API_KEY;

$ch = curl_init($listUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$result = array(
    'api_key_length' => strlen($API_KEY),
    'list_models_http_code' => $httpCode,
    'list_models_response' => json_decode($response, true)
);

// If listing works, try a simple generation
if ($httpCode == 200) {
    $models = json_decode($response, true);
    if (isset($models['models']) && count($models['models']) > 0) {
        $firstModel = $models['models'][0]['name'];
        $result['available_models'] = array_map(function($m) { return $m['name']; }, $models['models']);
        $result['first_model'] = $firstModel;
        
        // Try to generate with first available model
        $generateUrl = 'https://generativelanguage.googleapis.com/v1beta/' . $firstModel . ':generateContent?key=' . $API_KEY;
        
        $testPayload = json_encode(array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => 'Say hello')
                    )
                )
            )
        ));
        
        $ch2 = curl_init($generateUrl);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch2, CURLOPT_POST, true);
        curl_setopt($ch2, CURLOPT_POSTFIELDS, $testPayload);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch2, CURLOPT_TIMEOUT, 10);
        
        $testResponse = curl_exec($ch2);
        $testHttpCode = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
        curl_close($ch2);
        
        $result['test_generation_http_code'] = $testHttpCode;
        $result['test_generation_response'] = json_decode($testResponse, true);
        
        if ($testHttpCode == 200) {
            $result['status'] = 'SUCCESS - API key is working!';
        } else {
            $result['status'] = 'ERROR - API key valid but generation failed';
        }
    }
} else {
    $result['status'] = 'ERROR - Cannot list models. API key might be invalid or restricted.';
    $result['suggestion'] = 'Go to https://aistudio.google.com/app/apikey and verify your API key';
}

echo json_encode($result, JSON_PRETTY_PRINT);
?>