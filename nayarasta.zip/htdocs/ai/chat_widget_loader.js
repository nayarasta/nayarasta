// Chat Widget Loader - Add this script to your main pages

(function() {
    'use strict';

    // Configuration
    const CONFIG = {
        basePath: '/ai/',
        cssFile: 'chat_widget.css',
        htmlFile: 'chat_widget.html',
        jsFile: 'chat_widget_ui.js'
    };

    // Load CSS
    function loadCSS() {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CONFIG.basePath + CONFIG.cssFile;
        document.head.appendChild(link);
    }

    // Load HTML widget
    async function loadHTML() {
        try {
            const response = await fetch(CONFIG.basePath + CONFIG.htmlFile);
            const html = await response.text();
            
            const container = document.createElement('div');
            container.innerHTML = html;
            document.body.appendChild(container.firstElementChild);
        } catch (error) {
            console.error('Failed to load chat widget HTML:', error);
        }
    }

    // Load JavaScript
    function loadJS() {
        const script = document.createElement('script');
        script.src = CONFIG.basePath + CONFIG.jsFile;
        script.async = true;
        document.body.appendChild(script);
    }

    // Initialize widget
    async function init() {
        // Don't load on the ask.html page (full-page chat)
        if (window.location.pathname.includes('ask.html')) {
            return;
        }

        loadCSS();
        await loadHTML();
        loadJS();
    }

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();