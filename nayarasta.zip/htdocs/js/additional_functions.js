// Dashboard Ask to Expert Integration
// Add this to your existing dashboard JavaScript

// Expert Popup Configuration for Dashboard
const EXPERT_CONFIG = {
    whatsappNumber: '923328335332', // Your WhatsApp number
    showDelay: 1000, // Show popup after 1 second
    session: {
        time: 'Every Saturday at 8:00 PM',
        topic: 'Doubt Solving & MDCAT Strategy Session',
        expert: 'Dr. Tahir Baloch , Batch 2020'
    }
};

// Inject Expert Popup CSS (Dashboard Theme Compatible)
function injectExpertPopupCSS() {
    const css = `
        /* Expert Popup Styles - Matching Your Design */
        .expert-popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(5px);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            animation: expertFadeIn 0.3s ease-out;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .expert-popup-container {
            background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%);
            border-radius: 20px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
            max-width: 420px;
            width: 90%;
            position: relative;
            animation: expertSlideUp 0.4s ease-out;
            overflow: hidden;
        }

        .expert-popup-header {
            background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
            color: white;
            padding: 25px;
            text-align: center;
            position: relative;
        }

        .expert-popup-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
            animation: expertShine 3s infinite;
        }

        .expert-popup-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .expert-popup-subtitle {
            font-size: 14px;
            opacity: 0.9;
            font-weight: 500;
        }

        .expert-popup-body {
            padding: 30px 25px;
            text-align: center;
        }

        .expert-live-indicator {
            display: inline-flex;
            align-items: center;
            background: linear-gradient(135deg, #ff4757, #ff3742);
            color: white;
            padding: 8px 16px;
            border-radius: 25px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 20px;
            animation: expertPulse 2s infinite;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .expert-live-dot {
            width: 8px;
            height: 8px;
            background: white;
            border-radius: 50%;
            margin-right: 8px;
            animation: expertBlink 1s infinite;
        }

        .expert-session-info {
            background: linear-gradient(135deg, #f1f3f4 0%, #e8eaf0 100%);
            border-radius: 15px;
            padding: 20px;
            margin: 20px 0;
            border-left: 5px solid #25D366;
        }

        .expert-session-time {
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 8px;
        }

        .expert-session-topic {
            font-size: 14px;
            color: #34495e;
            margin-bottom: 12px;
            line-height: 1.5;
        }

        .expert-session-expert {
            font-size: 13px;
            color: #25D366;
            font-weight: bold;
        }

        .expert-whatsapp-btn {
            background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 30px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin: 20px 0;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(37, 211, 102, 0.3);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .expert-whatsapp-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(37, 211, 102, 0.4);
            color: white;
            text-decoration: none;
        }

        .expert-whatsapp-btn:active {
            transform: translateY(-1px);
        }

        .expert-whatsapp-icon {
            width: 20px;
            height: 20px;
        }

        .expert-close-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .expert-close-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1);
        }

        .expert-footer-text {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 15px;
            opacity: 0.8;
        }


        /* Responsive */
        @media (max-width: 480px) {
            .expert-popup-container {
                margin: 10px;
                width: calc(100% - 20px);
            }
            
            .expert-popup-title {
                font-size: 20px;
            }
            
            .expert-whatsapp-btn {
                padding: 12px 25px;
                font-size: 14px;
            }

        
        }
    `;

    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
}

// Create and inject Expert Popup HTML
function injectExpertPopupHTML() {
    const html = `
        <!-- Expert Popup -->
        <div id="expertPopup" class="expert-popup-overlay" style="display: none;">
            <div class="expert-popup-container">
                <div class="expert-popup-header">
                    <button class="expert-close-btn" onclick="closeExpertPopup()">&times;</button>
                    <h2 class="expert-popup-title">🎓 Ask to Expert</h2>
                    <p class="expert-popup-subtitle">MDCAT Live Session</p>
                </div>
                
                <div class="expert-popup-body">
                    <div class="expert-live-indicator">
                        <div class="expert-live-dot"></div>
                        Live Session
                    </div>
                    
                    <div class="expert-session-info">
                        <div class="expert-session-time" id="expertSessionTime">
                            Today at 8:00 PM
                        </div>
                        <div class="expert-session-topic" id="expertSessionTopic">
                            Physics Problem Solving & MDCAT Strategy Session
                        </div>
                        <div class="expert-session-expert" id="expertSessionExpert">
                            by Dr. Ahmad Khan - MDCAT Topper 2023
                        </div>
                    </div>
                    
                    <a href="https://wa.me/923328335332?text=I want to join the MDCAT live session today!" 
                       class="expert-whatsapp-btn" 
                       target="_blank"
                       onclick="trackExpertWhatsAppClick()">
                        <svg class="expert-whatsapp-icon" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488"/>
                        </svg>
                        Join WhatsApp Group
                    </a>
                    
                    <p class="expert-footer-text">💡 Free MDCAT guidance • Live Q&A • Expert tips</p>
                </div>
            </div>
        </div>

        <!-- Expert Trigger Button -->
            <i class="fas fa-user-tie"></i>
        </button>
    `;

    document.body.insertAdjacentHTML('beforeend', html);
}

// Function to show expert popup
function showExpertPopup() {
    updateExpertSessionInfo();
    document.getElementById('expertPopup').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

// Function to close expert popup
function closeExpertPopup() {
    document.getElementById('expertPopup').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Update expert session information
function updateExpertSessionInfo() {
    document.getElementById('expertSessionTime').textContent = EXPERT_CONFIG.session.time;
    document.getElementById('expertSessionTopic').textContent = EXPERT_CONFIG.session.topic;
    document.getElementById('expertSessionExpert').textContent = 'by ' + EXPERT_CONFIG.session.expert;
    
    const whatsappBtn = document.querySelector('.expert-whatsapp-btn');
    const message = encodeURIComponent(`I want to join the MDCAT live session: ${EXPERT_CONFIG.session.topic}`);
    whatsappBtn.href = `https://wa.me/${EXPERT_CONFIG.whatsappNumber}?text=${message}`;
}

// Track WhatsApp clicks
function trackExpertWhatsAppClick() {
    console.log('Expert WhatsApp link clicked');
    // Add your analytics tracking here
    // gtag('event', 'click', { 'event_category': 'Expert Session', 'event_label': 'WhatsApp Join' });
}

// Initialize expert popup
function initExpertPopup() {
    setTimeout(showExpertPopup, EXPERT_CONFIG.showDelay);
}

// Setup expert popup event listeners
function setupExpertEventListeners() {
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('expert-popup-overlay')) {
            closeExpertPopup();
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeExpertPopup();
        }
    });
}

// Dashboard Expert Integration Function
function initDashboardExpert() {
    injectExpertPopupCSS();
    injectExpertPopupHTML();
    setupExpertEventListeners();
    initExpertPopup();
}

// Add to dashboard navigation (if you have a navigation menu)
function addExpertToNavigation() {
    const navMenu = document.querySelector('.nav-menu, .sidebar-nav, .dashboard-nav');
    if (navMenu) {
        const expertNavItem = `
            <li class="nav-item">
                <a href="#" class="nav-link" onclick="showExpertPopup(); return false;">
                    <i class="fas fa-question-circle"></i>
                    <span>Ask to Expert</span>
                </a>
            </li>
        `;
        navMenu.insertAdjacentHTML('beforeend', expertNavItem);
    }
}

// Initialize when dashboard loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        initDashboardExpert();
        addExpertToNavigation();
    });
} else {
    initDashboardExpert();
    addExpertToNavigation();
}

// Manual trigger function for dashboard buttons
function showExpertSession() {
    showExpertPopup();
}
// Additional functions for results management
// Add this file to your HTML after script.js

// Show all results (Admin only)
async function showAllResults() {
    if (!currentUser || currentUser.role !== 'admin') {
        showAlert('Access denied. Admin privileges required.', 'danger');
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('results.php');
        const result = await response.json();
        
        if (result.status === 'success') {
            displayAllResults(result.data);
        } else {
            showAlert('Failed to load results.', 'danger');
        }
    } catch (error) {
        console.error('Error loading all results:', error);
        showAlert('Failed to load results.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Display all results (Admin view)
function displayAllResults(userResults) {
    const contentArea = document.getElementById('content-area');
    
    if (Object.keys(userResults).length === 0) {
        contentArea.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <h2 class="mb-4"><i class="fas fa-list-alt me-2"></i>All Results</h2>
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-chart-line fa-3x text-muted mb-3"></i>
                            <h5>No Results Yet</h5>
                            <p class="text-muted">No users have taken any tests yet.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        return;
    }
    
    let html = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-list-alt me-2"></i>All Results</h2>
                <div class="mb-3">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Showing results for all users. Total users with results: <strong>${Object.keys(userResults).length}</strong>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Create accordion for each user
    html += '<div class="accordion" id="allResultsAccordion">';
    
    Object.keys(userResults).forEach((username, userIndex) => {
        const results = userResults[username];
        const totalTests = results.length;
        const avgScore = Math.round(results.reduce((sum, result) => sum + (result.score / result.total * 100), 0) / totalTests);
        
        html += `
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#userResults${userIndex}">
                        <div class="w-100">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="fas fa-user me-2"></i><strong>${username}</strong>
                                </div>
                                <div class="text-end">
                                    <small class="text-muted">
                                        ${totalTests} test${totalTests > 1 ? 's' : ''} | 
                                        Avg: ${avgScore}%
                                    </small>
                                </div>
                            </div>
                        </div>
                    </button>
                </h2>
                <div id="userResults${userIndex}" class="accordion-collapse collapse" data-bs-parent="#allResultsAccordion">
                    <div class="accordion-body">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover">
                                <thead>
                                    <tr>
                                        <th>Test #</th>
                                        <th>Score</th>
                                        <th>Percentage</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
        `;
        
        results.forEach((result, index) => {
            const percentage = Math.round((result.score / result.total) * 100);
            const statusClass = percentage >= 70 ? 'success' : percentage >= 50 ? 'warning' : 'danger';
            
            html += `
                <tr>
                    <td><strong>#${results.length - index}</strong></td>
                    <td>${result.score} / ${result.total}</td>
                    <td>
                        <span class="badge bg-${statusClass}">${percentage}%</span>
                    </td>
                    <td>${new Date(result.date).toLocaleDateString()}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-info me-1" onclick="downloadResultPDF(${result.id})">
                            <i class="fas fa-download"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteResult(${result.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
        
        html += `
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    contentArea.innerHTML = html;
}

// Delete result (Admin only)
async function deleteResult(resultId) {
    if (!currentUser || currentUser.role !== 'admin') {
        showAlert('Access denied. Admin privileges required.', 'danger');
        return;
    }
    
    if (!confirm('Are you sure you want to delete this test result?')) {
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('results.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'delete',
                result_id: resultId
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert('Result deleted successfully!', 'success');
            showAllResults(); // Refresh the display
        } else {
            showAlert(result.message || 'Failed to delete result.', 'danger');
        }
    } catch (error) {
        console.error('Error deleting result:', error);
        showAlert('Failed to delete result.', 'danger');
    } finally {
        showLoading(false);
    }
}