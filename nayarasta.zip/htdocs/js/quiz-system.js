// MDCAT Online MCQs - Quiz System and Test Interface

// Chapter data for different subjects
const CHAPTERS = {
    'Biology': [
        'Acellular Life',
        'Bioenergetics',
        'Biological Molecules',
        'Cell Structure & Function',
        'Coordination & Control / Nervous & Chemical Coordination',
        'Enzymes',
        'Evolution',
        'Reproduction',
        'Support & Movement',
        'Inheritance',
        'Circulation',
        'Immunity',
        'Respiration',
        'Digestion',
        'Homeostasis',
        'Biotechnology'
    ],
    'Chemistry': [
        'Introduction of Fundamentals Concept of Chemistry',
        'Atomic Structure',
        'Gases',
        'Liquids',
        'Solid',
        'Chemical Equilibrium',
        'Reaction Kinetics',
        'Thermochemistry and Energetics of Chemical Reaction',
        'Electrochemistry',
        'Chemical Bonding',
        'S- and P- Block Elements',
        'Transition Elements',
        'Fundamental Principles of Organic Chemistry',
        'Chemistry of Hydrocarbons',
        'Alkyl Halides',
        'Alcohols and Phenols',
        'Aldehydes and Ketones',
        'Carboxylic Acids',
        'Macromolecules',
        'Industrial Chemistry'
    ],
    'Physics': [
        'Vectors and Equilibrium',
        'Force and Motion',
        'Work and Energy',
        'Rotational and Circular Motion',
        'Fluid Dynamics',
        'Waves',
        'Thermodynamics',
        'Electrostatics',
        'Current Electricity',
        'Electromagnetism',
        'Electromagnetic Induction',
        'Alternating Current',
        'Electronics',
        'Dawn of Modern Physics',
        'Atomic Spectra',
        'Nuclear Physics'
    ],
    'English': [
        'Reading and Thinking Skills',
        'Formal and Lexical Aspect of Language',
        'Writing Skills'
    ]
};

//start
// ============= ADD THIS AFTER THE CHAPTERS OBJECT =============
// (Add this right after the CHAPTERS object definition)

// Ranking system configuration
const RANK_SYSTEM = {
    'Bronze': { min: 0, max: 10, color: '#CD7F32', icon: 'fa-medal', bgColor: '#8B4513' },
    'Silver': { min: 11, max: 25, color: '#C0C0C0', icon: 'fa-medal', bgColor: '#708090' },
    'Gold': { min: 26, max: 45, color: '#FFD700', icon: 'fa-trophy', bgColor: '#DAA520' },
    'Platinum': { min: 46, max: 65, color: '#E5E4E2', icon: 'fa-crown', bgColor: '#71797E' },
    'Diamond': { min: 66, max: 80, color: '#B9F2FF', icon: 'fa-gem', bgColor: '#4682B4' },
    'Master': { min: 81, max: 90, color: '#9966CC', icon: 'fa-star', bgColor: '#8A2BE2' },
    'Grandmaster': { min: 91, max: 95, color: '#FF6B6B', icon: 'fa-fire', bgColor: '#DC143C' },
    'Ace': { min: 96, max: 97, color: '#4ECDC4', icon: 'fa-bolt', bgColor: '#008B8B' },
    'Ace Master': { min: 98, max: 99, color: '#45B7D1', icon: 'fa-rocket', bgColor: '#1E90FF' },
    'Conqueror': { min: 100, max: 100, color: '#FF69B4', icon: 'fa-crown', bgColor: '#FF1493' }
};

// Global variables for results data
let studentResultsData = [];
let currentRank = 'Bronze';
// Auto-save configuration
let autoSaveInterval = null;
let lastSavedAnswers = [];
let isAutoSaving = false;
let averagePercentage = 0;
//end

// Show test selection
async function showTestSelection() {
    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-play-circle me-2"></i>Select Test</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-list-alt fa-3x text-primary mb-3"></i>
                        <h5>Full Test</h5>
                        <p class="text-muted">Complete MCQ test with all questions</p>
                        <button class="btn btn-primary" onclick="startFullTest()">Start Full Test</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-filter fa-3x text-success mb-3"></i>
                        <h5>Full Book Test</h5>
                        <p class="text-muted">Test specific subject category</p>
                        <button class="btn btn-success" onclick="showCategorySelection()">Select Category</button>
                    </div>
                </div>
            </div>
<div class="col-md-3 mb-4">
    <div class="card h-100">
        <div class="card-body text-center">
            <i class="fas fa-bookmark fa-3x text-warning mb-3"></i>
            <h5>Chapter Test</h5>
            <p class="text-muted">Test specific chapter from any subject</p>
            <button class="btn btn-warning" onclick="showChapterSelection()">Select Chapter</button>
        </div>
    </div>
</div>
<div class="col-md-3 mb-4">
    <div class="card h-100">
        <div class="card-body text-center">
            <i class="fas fa-graduation-cap fa-3x text-info mb-3"></i>
            <h5>Mock Test</h5>
            <p class="text-muted">180 questions: Biology(81), Chemistry(45), Physics(36), English(18)</p>
            <button class="btn btn-info" onclick="startMockTest()">Start Mock Test</button>
        </div>
    </div>
</div>    `;
}

// Show category selection
function showCategorySelection() {
    const modal = new bootstrap.Modal(document.getElementById('categoryFilterModal'));
    modal.show();
}

// Show chapter selection
function showChapterSelection() {
    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-bookmark me-2"></i>Chapter-wise Test</h2>
                <div class="mb-3">
                    <button class="btn btn-outline-secondary" onclick="showTestSelection()">
                        <i class="fas fa-arrow-left me-2"></i>Back to Test Selection
                    </button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Select Subject and Chapter</h5>
                        
                        <div class="mb-3">
                            <label for="chapter-category-select" class="form-label">Select Subject:</label>
                            <select class="form-select" id="chapter-category-select" onchange="updateChapterOptions()">
                                <option value="">-- Select Subject --</option>
                                <option value="Biology">Biology</option>
                                <option value="Chemistry">Chemistry</option>
                                <option value="Physics">Physics</option>
                                <option value="English">English</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="chapter-select" class="form-label">Select Chapter:</label>
                            <select class="form-select" id="chapter-select" disabled>
                                <option value="">-- First Select Subject --</option>
                            </select>
                        </div>
                        
                        <div class="d-grid">
                            <button class="btn btn-warning" onclick="startChapterTest()" id="start-chapter-test" disabled>
                                <i class="fas fa-play me-2"></i>Start Chapter Test
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Update chapter options based on selected category
function updateChapterOptions() {
    const categorySelect = document.getElementById('chapter-category-select');
    const chapterSelect = document.getElementById('chapter-select');
    const startButton = document.getElementById('start-chapter-test');
    
    const selectedCategory = categorySelect.value;
    
    // Clear chapter options
    chapterSelect.innerHTML = '<option value="">-- Select Chapter --</option>';
    
    if (selectedCategory && CHAPTERS[selectedCategory]) {
        // Enable chapter dropdown
        chapterSelect.disabled = false;
        
        // Add chapters for selected category
        CHAPTERS[selectedCategory].forEach(chapter => {
            const option = document.createElement('option');
            option.value = chapter;
            option.textContent = chapter;
            chapterSelect.appendChild(option);
        });
        
        // Enable start button when chapter is selected
        chapterSelect.onchange = function() {
            startButton.disabled = !this.value;
        };
    } else {
        chapterSelect.disabled = true;
        startButton.disabled = true;
    }
}

// Apply category filter
async function applyCategoryFilter() {
    const category = document.getElementById('test-category-filter').value;
    bootstrap.Modal.getInstance(document.getElementById('categoryFilterModal')).hide();
    
    if (category) {
        await startCategoryTest(category);
    } else {
        await startFullTest();
    }
}

// Start full test
async function startFullTest() {
    await loadAndStartTest();
}

// Start category test
async function startCategoryTest(category) {
    await loadAndStartTest(category);
}

// Start chapter test
async function startChapterTest() {
    const category = document.getElementById('chapter-category-select').value;
    const chapter = document.getElementById('chapter-select').value;
    
    if (!category || !chapter) {
        showAlert('Please select both subject and chapter.', 'warning');
        return;
    }
    
    await loadAndStartTest(category, chapter);
}

// Start mock test
async function startMockTest() {
    await loadAndStartMockTest();
}

// Load and start mock test
async function loadAndStartMockTest() {
    try {
        showLoading(true);
        
        // Fetch questions for each subject with specific counts
        const subjects = [
            { name: 'Biology', count: 81 },
            { name: 'Chemistry', count: 45 },
            { name: 'Physics', count: 36 },
            { name: 'English', count: 18 }
        ];
        
        let allMockQuestions = [];
        
        for (const subject of subjects) {
            const response = await fetch(`mcq.php?type=mock&category=${encodeURIComponent(subject.name)}&limit=${subject.count}`);
            const result = await response.json();
            
            if (result.status === 'success' && result.data.length > 0) {
                // Take exactly the required number or available questions
                const questionsToAdd = result.data.slice(0, subject.count);
                allMockQuestions = allMockQuestions.concat(questionsToAdd);
            } else {
                showAlert(`Not enough questions available for ${subject.name}. Need ${subject.count} questions.`, 'warning');
                return;
            }
        }
        
        if (allMockQuestions.length === 180) {
            // Shuffle the combined questions for random order
            testMCQs = shuffleArray(allMockQuestions);
            userAnswers = new Array(testMCQs.length).fill(null);
            currentQuestionIndex = 0;
            
            startTestInterface(false, 'Mock Test (180 Questions)');
        } else {
            showAlert(`Mock test requires exactly 180 questions. Only ${allMockQuestions.length} questions available.`, 'warning');
        }
    } catch (error) {
        console.error('Error loading mock test:', error);
        showAlert('Failed to load mock test questions.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Shuffle array function
function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// Load and start test
async function loadAndStartTest(category = '', chapter = '') {
    try {
        showLoading(true);
        
        let url = 'mcq.php?type=regular';
        if (category) {
            url += `&category=${encodeURIComponent(category)}`;
        }
        if (chapter) {
            url += `&chapter=${encodeURIComponent(chapter)}`;
        }
        
        const response = await fetch(url);
        const result = await response.json();
        
        if (result.status === 'success' && result.data.length > 0) {
            testMCQs = result.data;
            userAnswers = new Array(testMCQs.length).fill(null);
            currentQuestionIndex = 0;
            
            // Set test type for results
            let testType = 'Full Test';
            if (category && chapter) {
                testType = `Chapter Test: ${category} - ${chapter}`;
            } else if (category) {
                testType = `Category Test: ${category}`;
            }
            
            startTestInterface(false, testType);
        } else {
            let errorMessage = 'No questions available for this test.';
            if (category && chapter) {
                errorMessage = `No questions available for ${category} - ${chapter}.`;
            } else if (category) {
                errorMessage = `No questions available for ${category}.`;
            }
            showAlert(errorMessage, 'warning');
        }
    } catch (error) {
        console.error('Error loading test:', error);
        showAlert('Failed to load test questions.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Start test interface
// Start test interface
function startTestInterface(isDemoMode = false, testType = 'Mixed') {
    currentTest = {
        isDemoMode: isDemoMode,
        startTime: new Date(),
        testType: testType
    };
    
    // Set test timer (30 minutes for regular, 10 minutes for demo)
    testTimeRemaining = isDemoMode ? 600 : 1800; // seconds
    
    displayTestInterface();
    startTestTimer();
    
    // Start auto-save for non-demo tests
    if (!isDemoMode && currentUser) {
        startAutoSave();
    }
    
    // Add beforeunload event listener to save progress when user leaves
    window.addEventListener('beforeunload', saveProgressBeforeExit);
}

// Start auto-save functionality
function startAutoSave() {
    // Clear any existing interval
    if (autoSaveInterval) {
        clearInterval(autoSaveInterval);
    }
    
    // Save progress every 10 seconds
    autoSaveInterval = setInterval(() => {
        saveCurrentProgress();
    }, 10000);
    
    // Initial save
    saveCurrentProgress();
}

// Save current test progress
async function saveCurrentProgress() {
    if (isAutoSaving || !currentUser || currentTest.isDemoMode) {
        return;
    }
    
    // Check if answers have changed since last save
    const answersString = JSON.stringify(userAnswers);
    if (answersString === JSON.stringify(lastSavedAnswers)) {
        return; // No changes, skip save
    }
    
    isAutoSaving = true;
    
    try {
        const currentScore = calculateScore();
        const response = await fetch('submit_result.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'submit',
                username: currentUser.username,
                score: currentScore,
                total: testMCQs.length,
                answers: userAnswers,
                test_type: (currentTest.testType || 'regular') + ' (Auto-saved)',
                is_partial: true
            })
        });
        
        if (response.ok) {
            lastSavedAnswers = [...userAnswers];
            console.log('Progress auto-saved successfully');
        }
    } catch (error) {
        console.error('Auto-save failed:', error);
    } finally {
        isAutoSaving = false;
    }
}

// Save progress before page unload
function saveProgressBeforeExit(event) {
    if (currentUser && !currentTest.isDemoMode && testMCQs.length > 0) {
        // Use navigator.sendBeacon for reliable sending during page unload
        const currentScore = calculateScore();
        const data = JSON.stringify({
            action: 'submit',
            username: currentUser.username,
            score: currentScore,
            total: testMCQs.length,
            answers: userAnswers,
            test_type: (currentTest.testType || 'regular') + ' (Incomplete)',
            is_partial: true
        });
        
        navigator.sendBeacon('submit_result.php', data);
    }
}

// Stop auto-save
function stopAutoSave() {
    if (autoSaveInterval) {
        clearInterval(autoSaveInterval);
        autoSaveInterval = null;
    }
    
    // Remove event listener
    window.removeEventListener('beforeunload', saveProgressBeforeExit);
}

// Display test interface
function displayTestInterface() {
    const contentArea = document.getElementById('content-area');
    const progress = ((currentQuestionIndex + 1) / testMCQs.length) * 100;
    
    contentArea.innerHTML = `
        <div class="test-interface">
            <div class="test-header mb-4">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h4><i class="fas fa-clock me-2"></i>Time: <span id="test-timer">00:00</span></h4>
                        <small class="text-muted">${currentTest.testType}</small>
                    </div>
                    <div class="col-md-6 text-end">
                        <h5>Question ${currentQuestionIndex + 1} of ${testMCQs.length}</h5>
                    </div>
                </div>
                <div class="test-progress">
                    <div class="test-progress-bar" style="width: ${progress}%"></div>
                </div>
            </div>
            
            <div class="test-question-card card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Q${currentQuestionIndex + 1}. ${testMCQs[currentQuestionIndex].question}</h5>
                    <div id="question-options">
                        ${generateQuestionOptions()}
                    </div>
                </div>
            </div>
            
            <div class="test-controls mt-4">
                <div class="row">
                    <div class="col-md-6">
                        <button class="btn btn-outline-secondary" onclick="previousQuestion()" ${currentQuestionIndex === 0 ? 'disabled' : ''}>
                            <i class="fas fa-arrow-left me-2"></i>Previous
                        </button>
                    </div>
                    <div class="col-md-6 text-end">
                        ${currentQuestionIndex === testMCQs.length - 1 ? 
                            '<button class="btn btn-success" onclick="finishTest()"><i class="fas fa-check me-2"></i>Finish Test</button>' :
                            '<button class="btn btn-primary" onclick="nextQuestion()">Next<i class="fas fa-arrow-right ms-2"></i></button>'
                        }
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Generate question options
function generateQuestionOptions() {
    const currentQuestion = testMCQs[currentQuestionIndex];
    const selectedAnswer = userAnswers[currentQuestionIndex];
    
    return currentQuestion.options.map((option, index) => `
        <div class="option-card ${selectedAnswer === index ? 'selected' : ''}" onclick="selectAnswer(${index})">
            <div class="d-flex align-items-center">
                <div class="me-3">
                    <strong>${String.fromCharCode(65 + index)}.</strong>
                </div>
                <div class="flex-grow-1">
                    ${option}
                </div>
                <div class="ms-3">
                    <i class="fas fa-circle ${selectedAnswer === index ? 'text-primary' : 'text-muted'}"></i>
                </div>
            </div>
        </div>
    `).join('');
}

// Select answer
// Select answer
function selectAnswer(answerIndex) {
    userAnswers[currentQuestionIndex] = answerIndex;
    
    // Update option display
    const options = document.querySelectorAll('.option-card');
    options.forEach((option, index) => {
        option.classList.toggle('selected', index === answerIndex);
        const icon = option.querySelector('i');
        icon.classList.toggle('text-primary', index === answerIndex);
        icon.classList.toggle('text-muted', index !== answerIndex);
    });
    
    // Trigger immediate save for important answers
    if (!currentTest.isDemoMode && currentUser) {
        setTimeout(saveCurrentProgress, 1000);
    }
}

// Previous question
function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        displayTestInterface();
    }
}

// Next question
function nextQuestion() {
    if (currentQuestionIndex < testMCQs.length - 1) {
        currentQuestionIndex++;
        displayTestInterface();
    }
}

// Start test timer
function startTestTimer() {
    testTimer = setInterval(() => {
        testTimeRemaining--;
        updateTimerDisplay();
        
        if (testTimeRemaining <= 0) {
            clearInterval(testTimer);
            finishTest();
        }
    }, 1000);
}

// Update timer display
function updateTimerDisplay() {
    const timerElement = document.getElementById('test-timer');
    if (timerElement) {
        const minutes = Math.floor(testTimeRemaining / 60);
        const seconds = testTimeRemaining % 60;
        timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        // Change color when time is running low
        if (testTimeRemaining <= 300) { // 5 minutes
            timerElement.classList.add('text-danger');
        }
    }
}

// Finish test
// Finish test
async function finishTest() {
    clearInterval(testTimer);
    stopAutoSave(); // Stop auto-saving when test is finished
    
    // Calculate score
    let score = 0;
    testMCQs.forEach((mcq, index) => {
        if (userAnswers[index] === mcq.answer) {
            score++;
        }
    });
    
    // Show results
    showTestResults(score);
    
    // Save final results to backend (only for regular tests)
    if (!currentTest.isDemoMode && currentUser) {
        try {
            await fetch('submit_result.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'submit',
                    username: currentUser.username,
                    score: score,
                    total: testMCQs.length,
                    answers: userAnswers,
                    test_type: currentTest.testType || 'regular',
                    is_partial: false // Mark as complete
                })
            });
        } catch (error) {
            console.error('Error saving results:', error);
        }
    }
}

// Show test results
function showTestResults(score) {
    const percentage = Math.round((score / testMCQs.length) * 100);
    const contentArea = document.getElementById('content-area');
    
    contentArea.innerHTML = `
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card text-center">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-trophy me-2"></i>Test Results</h4>
                        <small>${currentTest.testType}</small>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <h2 class="text-primary">${score}</h2>
                                <p class="text-muted">Correct Answers</p>
                            </div>
                            <div class="col-md-4">
                                <h2 class="text-info">${testMCQs.length}</h2>
                                <p class="text-muted">Total Questions</p>
                            </div>
                            <div class="col-md-4">
                                <h2 class="text-success">${percentage}%</h2>
                                <p class="text-muted">Percentage</p>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <div class="progress" style="height: 20px;">
                                <div class="progress-bar bg-success" style="width: ${percentage}%"></div>
                            </div>
                        </div>
                        
                        <div class="alert ${percentage >= 70 ? 'alert-success' : percentage >= 50 ? 'alert-warning' : 'alert-danger'}">
                            <h5>${percentage >= 70 ? 'Excellent!' : percentage >= 50 ? 'Good Job!' : 'Keep Practicing!'}</h5>
                            <p class="mb-0">
                                ${percentage >= 70 ? 'Great performance! Keep up the excellent work.' : 
                                  percentage >= 50 ? 'Good effort! A little more practice will help you improve.' : 
                                  'Don\'t worry! More practice will help you improve your score.'}
                            </p>
                        </div>
                        
                        <div class="mt-4">
                            <button class="btn btn-primary me-2" onclick="showDetailedResults()">
                                <i class="fas fa-list me-2"></i>View Detailed Results
                            </button>
                            <button class="btn btn-success me-2" onclick="showTestSelection()">
                                <i class="fas fa-redo me-2"></i>Take Another Test
                            </button>
                            <button class="btn btn-outline-secondary" onclick="showDashboard()">
                                <i class="fas fa-home me-2"></i>Back to Dashboard
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Show detailed results
function showDetailedResults() {
    const contentArea = document.getElementById('content-area');
    let detailedHTML = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-list-alt me-2"></i>Detailed Results</h2>
                <p class="text-muted mb-3">${currentTest.testType}</p>
                <div class="mb-3">
                    <button class="btn btn-outline-secondary" onclick="showTestResults(${calculateScore()})">
                        <i class="fas fa-arrow-left me-2"></i>Back to Summary
                    </button>
                </div>
            </div>
        </div>
        <div class="accordion" id="detailedResultsAccordion">
    `;
    
    testMCQs.forEach((mcq, index) => {
        const userAnswer = userAnswers[index];
        const isCorrect = userAnswer === mcq.answer;
        const statusClass = isCorrect ? 'success' : 'danger';
        const statusIcon = isCorrect ? 'fa-check-circle' : 'fa-times-circle';
        
        detailedHTML += `
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${index}">
                        <i class="fas ${statusIcon} text-${statusClass} me-2"></i>
                        Q${index + 1}. ${mcq.question.substring(0, 80)}${mcq.question.length > 80 ? '...' : ''}
                    </button>
                </h2>
                <div id="collapse${index}" class="accordion-collapse collapse" data-bs-parent="#detailedResultsAccordion">
                    <div class="accordion-body">
                        <h6>${mcq.question}</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Options:</h6>
                                <ul class="list-unstyled">
                                    ${mcq.options.map((option, optIndex) => `
                                        <li class="mb-2">
                                            <span class="badge ${optIndex === mcq.answer ? 'bg-success' : optIndex === userAnswer ? 'bg-danger' : 'bg-secondary'}">
                                                ${String.fromCharCode(65 + optIndex)}
                                            </span>
                                            ${option}
                                        </li>
                                    `).join('')}
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h6>Result:</h6>
                                <p><strong>Your Answer:</strong> ${userAnswer !== null ? String.fromCharCode(65 + userAnswer) : 'Not Answered'}</p>
                                <p><strong>Correct Answer:</strong> ${String.fromCharCode(65 + mcq.answer)}</p>
                                <p><strong>Status:</strong> 
                                    <span class="badge bg-${statusClass}">
                                        ${isCorrect ? 'Correct' : 'Incorrect'}
                                    </span>
                                </p>
                                <p><strong>Category:</strong> <span class="badge bg-info">${mcq.category}</span></p>
                                ${mcq.chapter ? `<p><strong>Chapter:</strong> <span class="badge bg-warning">${mcq.chapter}</span></p>` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    detailedHTML += '</div>';
    contentArea.innerHTML = detailedHTML;
}

// Calculate current score
function calculateScore() {
    let score = 0;
    testMCQs.forEach((mcq, index) => {
        if (userAnswers[index] === mcq.answer) {
            score++;
        }
    });
    return score;
}

// start from her
// Calculate rank and average percentage
function calculateRankAndAverage() {
    if (studentResultsData.length === 0) {
        averagePercentage = 0;
        currentRank = 'Bronze';
        return;
    }
    
    const totalPercentage = studentResultsData.reduce((sum, result) => {
        const percentage = Math.round((result.score / result.total) * 100);
        return sum + percentage;
    }, 0);
    
    averagePercentage = Math.round(totalPercentage / studentResultsData.length);
    
    // Determine rank based on average percentage
    for (const [rank, config] of Object.entries(RANK_SYSTEM)) {
        if (averagePercentage >= config.min && averagePercentage <= config.max) {
            currentRank = rank;
            break;
        }
    }
}

// Get rank configuration
function getRankConfig(rank) {
    return RANK_SYSTEM[rank] || RANK_SYSTEM['Bronze'];
}

// Get subject-wise performance data
function getSubjectPerformance() {
    const subjectData = {
        'Biology': { total: 0, correct: 0, tests: 0 },
        'Chemistry': { total: 0, correct: 0, tests: 0 },
        'Physics': { total: 0, correct: 0, tests: 0 },
        'English': { total: 0, correct: 0, tests: 0 }
    };
    
    studentResultsData.forEach(result => {
        // Extract subject from test_type if available
        const testType = result.test_type || 'Mixed';
        let subject = 'Mixed';
        
        if (testType.includes('Biology')) subject = 'Biology';
        else if (testType.includes('Chemistry')) subject = 'Chemistry';
        else if (testType.includes('Physics')) subject = 'Physics';
        else if (testType.includes('English')) subject = 'English';
        
        if (subjectData[subject]) {
            subjectData[subject].total += result.total;
            subjectData[subject].correct += result.score;
            subjectData[subject].tests += 1;
        }
    });
    
    // Calculate percentages
    Object.keys(subjectData).forEach(subject => {
        const data = subjectData[subject];
        data.percentage = data.total > 0 ? Math.round((data.correct / data.total) * 100) : 0;
    });
    
    return subjectData;
}

// Display enhanced results with charts and rank system
function displayEnhancedResults() {
    const contentArea = document.getElementById('content-area');
    const rankConfig = getRankConfig(currentRank);
    const subjectData = getSubjectPerformance();
    
    // Prepare chart data
    const chartLabels = Object.keys(subjectData);
    const chartData = chartLabels.map(subject => subjectData[subject].percentage);
    const chartColors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'];
    
    contentArea.innerHTML = `
        <style>
        .rank-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: rankGlow 2s ease-in-out infinite alternate;
        }
        .rank-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        @keyframes rankGlow {
            from { box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
            to { box-shadow: 0 8px 25px rgba(0,0,0,0.2); }
        }
        .rank-icon {
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
        }
        .stats-card {
            transition: transform 0.2s ease;
            border-left: 4px solid transparent;
        }
        .stats-card:hover {
            transform: translateY(-2px);
            border-left-color: #007bff;
        }
        .rank-progression {
            text-align: center;
        }
        .rank-item {
            display: inline-block;
            padding: 15px;
            margin: 5px;
            border: 2px solid #ddd;
            border-radius: 10px;
            transition: all 0.3s ease;
            min-width: 80px;
        }
        .rank-item.current-rank {
            transform: scale(1.1);
            animation: currentRankPulse 2s ease-in-out infinite alternate;
        }
        @keyframes currentRankPulse {
            from { box-shadow: 0 0 20px rgba(255,215,0,0.5); }
            to { box-shadow: 0 0 30px rgba(255,215,0,0.8); }
        }
        .rank-item.achieved {
            background: rgba(40, 167, 69, 0.1);
        }
        .rank-item.locked {
            opacity: 0.5;
            background: rgba(108, 117, 125, 0.1);
        }
        .rank-name {
            font-weight: bold;
            margin: 5px 0;
            font-size: 0.9rem;
        }
        .rank-range {
            font-size: 0.8rem;
            color: #666;
        }
        .rank-progress .progress {
            background: rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        </style>
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-chart-line me-2"></i>My Results & Progress</h2>
            </div>
        </div>
        
        <!-- Rank Card -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card rank-card" style="background: linear-gradient(135deg, ${rankConfig.bgColor}20, ${rankConfig.color}20); border: 2px solid ${rankConfig.color};">
                    <div class="card-body text-center py-4">
                        <div class="rank-display">
                            <i class="fas ${rankConfig.icon} rank-icon" style="color: ${rankConfig.color}; font-size: 3rem; margin-bottom: 15px;"></i>
                            <h3 style="color: ${rankConfig.color}; font-weight: bold; margin-bottom: 10px;">${currentRank}</h3>
                            <h5 class="text-muted">Average: ${averagePercentage}%</h5>
                            <div class="rank-progress mt-3">
                                <div class="progress" style="height: 10px;">
                                    <div class="progress-bar" style="width: ${averagePercentage}%; background-color: ${rankConfig.color};"></div>
                                </div>
                            </div>
                            <small class="text-muted mt-2 d-block">Based on ${studentResultsData.length} test${studentResultsData.length !== 1 ? 's' : ''}</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stats-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-clipboard-list fa-2x text-primary mb-2"></i>
                        <h4 class="text-primary">${studentResultsData.length}</h4>
                        <p class="text-muted mb-0">Total Tests</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stats-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-percentage fa-2x text-success mb-2"></i>
                        <h4 class="text-success">${averagePercentage}%</h4>
                        <p class="text-muted mb-0">Average Score</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stats-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-trophy fa-2x text-warning mb-2"></i>
                        <h4 class="text-warning">${getBestScore()}%</h4>
                        <p class="text-muted mb-0">Best Score</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stats-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-line fa-2x text-info mb-2"></i>
                        <h4 class="text-info">${getRecentTrend()}</h4>
                        <p class="text-muted mb-0">Recent Trend</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Charts Section -->
        <div class="row mb-4">
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5><i class="fas fa-chart-bar me-2"></i>Subject Performance</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="subjectChart" width="400" height="300"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5><i class="fas fa-chart-line me-2"></i>Progress Over Time</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="progressChart" width="400" height="300"></canvas>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Rank Progression -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-medal me-2"></i>Rank System</h5>
                    </div>
                    <div class="card-body">
                        <div class="rank-progression">
                            ${generateRankProgression()}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Test History -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-history me-2"></i>Test History</h5>
                    </div>
                    <div class="card-body">
                        ${generateTestHistory()}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Initialize charts after DOM is ready
    setTimeout(() => {
        initializeCharts(chartLabels, chartData, chartColors);
    }, 100);
}

// Generate rank progression display
function generateRankProgression() {
    let html = '<div class="row">';
    let col = 0;
    
    Object.entries(RANK_SYSTEM).forEach(([rank, config]) => {
        const isCurrentRank = rank === currentRank;
        const isAchieved = averagePercentage >= config.min;
        
        if (col % 5 === 0 && col > 0) {
            html += '</div><div class="row mt-3">';
        }
        
        html += `
            <div class="col">
                <div class="rank-item ${isCurrentRank ? 'current-rank' : ''} ${isAchieved ? 'achieved' : 'locked'}" 
                     style="border-color: ${config.color};">
                    <i class="fas ${config.icon}" style="color: ${isAchieved ? config.color : '#ccc'};"></i>
                    <div class="rank-name" style="color: ${isAchieved ? config.color : '#ccc'};">${rank}</div>
                    <div class="rank-range">${config.min}${config.max !== config.min ? '-' + config.max : ''}%</div>
                </div>
            </div>
        `;
        col++;
    });
    
    html += '</div>';
    return html;
}

// Generate test history table
function generateTestHistory() {
    if (studentResultsData.length === 0) {
        return '<div class="text-center text-muted py-4"><i class="fas fa-inbox fa-3x mb-3"></i><p>No test history available</p></div>';
    }
    
    let html = `
        <div class="table-responsive">
            <table class="table table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Test #</th>
                        <th>Type</th>
                        <th>Score</th>
                        <th>Percentage</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    studentResultsData.forEach((result, index) => {
        const percentage = Math.round((result.score / result.total) * 100);
        const badgeClass = percentage >= 80 ? 'success' : percentage >= 60 ? 'warning' : 'danger';
        
        html += `
            <tr>
                <td>#${index + 1}</td>
                <td><span class="badge bg-info">${result.test_type || 'Mixed'}</span></td>
                <td>${result.score} / ${result.total}</td>
                <td><span class="badge bg-${badgeClass}">${percentage}%</span></td>
                <td>${formatDate(result.date_taken)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="viewTestDetails(${index})">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    return html;
}

// Initialize charts
function initializeCharts(labels, data, colors) {
    // Subject Performance Chart
    const subjectCtx = document.getElementById('subjectChart');
    if (subjectCtx) {
        new Chart(subjectCtx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: colors,
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    // Progress Over Time Chart
    const progressCtx = document.getElementById('progressChart');
    if (progressCtx && studentResultsData.length > 0) {
        const progressData = studentResultsData.map((result, index) => ({
            x: index + 1,
            y: Math.round((result.score / result.total) * 100)
        }));
        
        new Chart(progressCtx, {
            type: 'line',
            data: {
                datasets: [{
                    label: 'Score %',
                    data: progressData,
                    borderColor: '#36A2EB',
                    backgroundColor: '#36A2EB20',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Test Number'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Percentage'
                        },
                        min: 0,
                        max: 100
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
}

// Helper functions
function getBestScore() {
    if (studentResultsData.length === 0) return 0;
    const scores = studentResultsData.map(result => Math.round((result.score / result.total) * 100));
    return Math.max(...scores);
}

function getRecentTrend() {
    if (studentResultsData.length < 2) return 'N/A';
    const recent = studentResultsData.slice(-3).map(result => Math.round((result.score / result.total) * 100));
    const avg1 = recent.slice(0, Math.ceil(recent.length / 2)).reduce((a, b) => a + b, 0) / Math.ceil(recent.length / 2);
    const avg2 = recent.slice(-Math.floor(recent.length / 2)).reduce((a, b) => a + b, 0) / Math.floor(recent.length / 2);
    
    if (avg2 > avg1) return '↗ Improving';
    else if (avg2 < avg1) return '↘ Declining';
    else return '→ Stable';
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

function viewTestDetails(index) {
    showAlert(`Test details for test #${index + 1} - Feature coming soon!`, 'info');
}

function viewTestDetails(index) {
    const result = studentResultsData[index];
    if (!result) {
        showAlert('Test details not found.', 'danger');
        return;
    }
    
    const percentage = Math.round((result.score / result.total) * 100);
    const rankConfig = getRankConfig(currentRank);
    
    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-file-alt me-2"></i>Test Details - #${index + 1}</h2>
                <div class="mb-3">
                    <button class="btn btn-outline-secondary" onclick="displayEnhancedResults()">
                        <i class="fas fa-arrow-left me-2"></i>Back to Results
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Test Summary Card -->
        <div class="row mb-4">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5><i class="fas fa-info-circle me-2"></i>Test Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center mb-3">
                            <div class="col-md-3">
                                <h3 class="text-primary">${result.score}</h3>
                                <p class="text-muted mb-0">Correct</p>
                            </div>
                            <div class="col-md-3">
                                <h3 class="text-danger">${result.total - result.score}</h3>
                                <p class="text-muted mb-0">Incorrect</p>
                            </div>
                            <div class="col-md-3">
                                <h3 class="text-info">${result.total}</h3>
                                <p class="text-muted mb-0">Total</p>
                            </div>
                            <div class="col-md-3">
                                <h3 class="text-success">${percentage}%</h3>
                                <p class="text-muted mb-0">Score</p>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="progress" style="height: 25px;">
                                <div class="progress-bar bg-success" style="width: ${percentage}%">
                                    ${percentage}%
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Test Type:</strong> <span class="badge bg-info">${result.test_type || 'Mixed'}</span></p>
                                <p><strong>Date Taken:</strong> ${formatDate(result.date_taken)}</p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Status:</strong> 
                                    <span class="badge bg-${result.is_partial ? 'warning' : 'success'}">
                                        ${result.is_partial ? 'Partial/Auto-saved' : 'Completed'}
                                    </span>
                                </p>
                                <p><strong>Performance:</strong> 
                                    <span class="badge bg-${percentage >= 80 ? 'success' : percentage >= 60 ? 'warning' : 'danger'}">
                                        ${percentage >= 80 ? 'Excellent' : percentage >= 60 ? 'Good' : 'Needs Improvement'}
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Answer Breakdown -->
        ${result.answers && result.answers.length > 0 ? generateAnswerBreakdown(result) : `
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle me-2"></i>
                        Detailed answer breakdown is not available for this test.
                    </div>
                </div>
            </div>
        `}
    `;
}

function generateAnswerBreakdown(result) {
    // Parse answers if stored as JSON string
    let answers = result.answers;
    if (typeof answers === 'string') {
        try {
            answers = JSON.parse(answers);
        } catch (e) {
            console.error('Error parsing answers:', e);
            return '<div class="alert alert-warning">Unable to parse answer details.</div>';
        }
    }
    
    if (!Array.isArray(answers) || answers.length === 0) {
        return '<div class="alert alert-info">No answer details available.</div>';
    }
    
    // Count answered vs unanswered
    const answeredCount = answers.filter(a => a !== null).length;
    const unansweredCount = answers.length - answeredCount;
    
    let html = `
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-list-check me-2"></i>Answer Breakdown</h5>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fas fa-check-circle text-success me-2"></i>
                                    <span>Answered: <strong>${answeredCount}</strong> questions</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fas fa-times-circle text-warning me-2"></i>
                                    <span>Unanswered: <strong>${unansweredCount}</strong> questions</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th width="80">Q#</th>
                                        <th>Your Answer</th>
                                        <th width="120">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
    `;
    
    answers.forEach((answer, qIndex) => {
        const answerLetter = answer !== null ? String.fromCharCode(65 + answer) : '-';
        const statusBadge = answer !== null ? 
            '<span class="badge bg-primary">Answered</span>' : 
            '<span class="badge bg-secondary">Skipped</span>';
        
        html += `
            <tr>
                <td class="text-center"><strong>${qIndex + 1}</strong></td>
                <td class="text-center">
                    ${answer !== null ? 
                        `<span class="badge bg-info">${answerLetter}</span>` : 
                        '<span class="text-muted">No answer</span>'}
                </td>
                <td class="text-center">${statusBadge}</td>
            </tr>
        `;
    });
    
    html += `
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="alert alert-info mt-3 mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            <small>Note: Correct answers and question details are only available during test review. 
                            This breakdown shows your response pattern for this test.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    return html;
}