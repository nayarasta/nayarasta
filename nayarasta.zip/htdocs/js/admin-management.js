// Chapter Management Functions
// Add this to your existing admin_management.js file or create as a separate file

// Chapter data structure for admin interface
const ADMIN_CHAPTERS = {
    'Physics': [
        'Vectors and Equilibrium',
        'Force and Motion', 
        'Work and Energy',
        'Rotational and Circular Motion',
        'Fluid Dynamics',
        'Waves',
        'Thermodynamics',
        'Electrostatics',
        'Current Electricity',
        'Electromagnetism',
        'Electromagnetic Induction',
        'Alternating Current',
        'Electronics',
        'Dawn of Modern Physics',
        'Atomic Spectra',
        'Nuclear Physics'
    ],
    'Chemistry': [
        'Introduction of Fundamentals Concept of Chemistry',
        'Atomic Structure',
        'Gases',
        'Liquids',
        'Solid',
        'Chemical Equilibrium',
        'Reaction Kinetics',
        'Thermochemistry and Energetics of Chemical Reaction',
        'Electrochemistry',
        'Chemical Bonding',
        'S- and P- Block Elements',
        'Transition Elements',
        'Fundamental Principles of Organic Chemistry',
        'Chemistry of Hydrocarbons',
        'Alkyl Halides',
        'Alcohols and Phenols',
        'Aldehydes and Ketones',
        'Carboxylic Acids',
        'Macromolecules',
        'Industrial Chemistry'
    ],
    'Biology': [
        'Acellular Life',
        'Bioenergetics',
        'Biological Molecules',
        'Cell Structure & Function',
        'Coordination & Control / Nervous & Chemical Coordination',
        'Enzymes',
        'Evolution',
        'Reproduction',
        'Support & Movement',
        'Inheritance',
        'Circulation',
        'Immunity',
        'Respiration',
        'Digestion',
        'Homeostasis',
        'Biotechnology'
    ],
    'English': [
        'Reading and Thinking Skills',
        'Formal and Lexical Aspect of Language',
        'Writing Skills'
    ]
};

// Function to populate chapter dropdown based on selected category
function populateAdminChapterDropdown(categoryValue, chapterDropdownId) {
    const chapterDropdown = document.getElementById(chapterDropdownId);
    
    if (!chapterDropdown) {
        console.error('Chapter dropdown not found:', chapterDropdownId);
        return;
    }
    
    // Clear existing options
    chapterDropdown.innerHTML = '<option value="">-- Select Chapter --</option>';
    
    if (categoryValue && ADMIN_CHAPTERS[categoryValue]) {
        // Add chapters for selected category
        ADMIN_CHAPTERS[categoryValue].forEach((chapter, index) => {
            const option = document.createElement('option');
            option.value = chapter;
            option.textContent = `${index + 1}. ${chapter}`;
            chapterDropdown.appendChild(option);
        });
        
        chapterDropdown.disabled = false;
    } else {
        chapterDropdown.disabled = true;
    }
}

// Enhanced function to show add MCQ modal with chapter support
function showAddMCQModalWithChapter() {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal fade" id="addMCQModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New MCQ</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addMCQForm">
                            <div class="mb-3">
                                <label class="form-label">Question:</label>
                                <textarea class="form-control" id="mcq-question" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Category:</label>
                                <select class="form-control" id="mcq-category" required onchange="populateAdminChapterDropdown(this.value, 'mcq-chapter')">
                                    <option value="">Select Category</option>
                                    <option value="Physics">Physics</option>
                                    <option value="Chemistry">Chemistry</option>
                                    <option value="Biology">Biology</option>
                                    <option value="English">English</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Chapter:</label>
                                <select class="form-control" id="mcq-chapter" disabled>
                                    <option value="">-- Select Chapter --</option>
                                </select>
                                <div class="form-text">Select a category first to see available chapters.</div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option A:</label>
                                <input type="text" class="form-control" id="mcq-option-a" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option B:</label>
                                <input type="text" class="form-control" id="mcq-option-b" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option C:</label>
                                <input type="text" class="form-control" id="mcq-option-c" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option D:</label>
                                <input type="text" class="form-control" id="mcq-option-d" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Correct Answer:</label>
                                <select class="form-control" id="mcq-answer" required>
                                    <option value="">Select Correct Answer</option>
                                    <option value="0">A</option>
                                    <option value="1">B</option>
                                    <option value="2">C</option>
                                    <option value="3">D</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="submitMCQWithChapter()">Add MCQ</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    new bootstrap.Modal(document.getElementById('addMCQModal')).show();
}

// Enhanced submit MCQ function with chapter support
async function submitMCQWithChapter() {
    const question = document.getElementById('mcq-question').value.trim();
    const category = document.getElementById('mcq-category').value;
    const chapter = document.getElementById('mcq-chapter').value.trim();
    const optionA = document.getElementById('mcq-option-a').value.trim();
    const optionB = document.getElementById('mcq-option-b').value.trim();
    const optionC = document.getElementById('mcq-option-c').value.trim();
    const optionD = document.getElementById('mcq-option-d').value.trim();
    const answer = parseInt(document.getElementById('mcq-answer').value);

    if (!question || !category || !optionA || !optionB || !optionC || !optionD || isNaN(answer)) {
        alert('Please fill all required fields.');
        return;
    }

    try {
        const response = await fetch('mcq.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                question: question,
                options: [optionA, optionB, optionC, optionD],
                answer: answer,
                category: category,
                chapter: chapter, // Include chapter
                type: 'regular',
                username: currentUser ? currentUser.username : 'admin'
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            alert('MCQ added successfully!');
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('addMCQModal'));
            if (modal) modal.hide();
            // Refresh MCQ list if function exists
            if (typeof showMCQManagement === 'function') {
                showMCQManagement();
            }
        } else {
            alert('Error: ' + (result.message || 'Failed to add MCQ.'));
        }
    } catch (error) {
        console.error('Error adding MCQ:', error);
        alert('Failed to add MCQ. Please try again.');
    }
}

// Function to edit MCQ with chapter support
function showEditMCQModalWithChapter(mcq) {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal fade" id="editMCQModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit MCQ - #${mcq.id}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="editMCQForm">
                            <input type="hidden" id="edit-mcq-id" value="${mcq.id}">
                            <div class="mb-3">
                                <label class="form-label">Question:</label>
                                <textarea class="form-control" id="edit-mcq-question" rows="3" required>${mcq.question}</textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Category:</label>
                                <select class="form-control" id="edit-mcq-category" required onchange="populateAdminChapterDropdown(this.value, 'edit-mcq-chapter')">
                                    <option value="Physics" ${mcq.category === 'Physics' ? 'selected' : ''}>Physics</option>
                                    <option value="Chemistry" ${mcq.category === 'Chemistry' ? 'selected' : ''}>Chemistry</option>
                                    <option value="Biology" ${mcq.category === 'Biology' ? 'selected' : ''}>Biology</option>
                                    <option value="English" ${mcq.category === 'English' ? 'selected' : ''}>English</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Chapter:</label>
                                <select class="form-control" id="edit-mcq-chapter">
                                    <option value="">-- Select Chapter --</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option A:</label>
                                <input type="text" class="form-control" id="edit-mcq-option-a" value="${mcq.options[0]}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option B:</label>
                                <input type="text" class="form-control" id="edit-mcq-option-b" value="${mcq.options[1]}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option C:</label>
                                <input type="text" class="form-control" id="edit-mcq-option-c" value="${mcq.options[2]}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option D:</label>
                                <input type="text" class="form-control" id="edit-mcq-option-d" value="${mcq.options[3]}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Correct Answer:</label>
                                <select class="form-control" id="edit-mcq-answer" required>
                                    <option value="0" ${mcq.answer === 0 ? 'selected' : ''}>A</option>
                                    <option value="1" ${mcq.answer === 1 ? 'selected' : ''}>B</option>
                                    <option value="2" ${mcq.answer === 2 ? 'selected' : ''}>C</option>
                                    <option value="3" ${mcq.answer === 3 ? 'selected' : ''}>D</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="updateMCQWithChapter()">Update MCQ</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    // Show the modal first
    const modalInstance = new bootstrap.Modal(document.getElementById('editMCQModal'));
    modalInstance.show();
    
    // Then populate chapters and set the selected chapter
    setTimeout(() => {
        populateAdminChapterDropdown(mcq.category, 'edit-mcq-chapter');
        setTimeout(() => {
            if (mcq.chapter) {
                document.getElementById('edit-mcq-chapter').value = mcq.chapter;
            }
        }, 100);
    }, 100);
}

// Enhanced update MCQ function with chapter support
async function updateMCQWithChapter() {
    const id = parseInt(document.getElementById('edit-mcq-id').value);
    const question = document.getElementById('edit-mcq-question').value.trim();
    const category = document.getElementById('edit-mcq-category').value;
    const chapter = document.getElementById('edit-mcq-chapter').value.trim();
    const optionA = document.getElementById('edit-mcq-option-a').value.trim();
    const optionB = document.getElementById('edit-mcq-option-b').value.trim();
    const optionC = document.getElementById('edit-mcq-option-c').value.trim();
    const optionD = document.getElementById('edit-mcq-option-d').value.trim();
    const answer = parseInt(document.getElementById('edit-mcq-answer').value);

    if (!question || !category || !optionA || !optionB || !optionC || !optionD || isNaN(answer)) {
        alert('Please fill all required fields.');
        return;
    }

    try {
        const response = await fetch('mcq.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'update',
                id: id,
                question: question,
                options: [optionA, optionB, optionC, optionD],
                answer: answer,
                category: category,
                chapter: chapter, // Include chapter
                username: currentUser ? currentUser.username : 'admin'
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            alert('MCQ updated successfully!');
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('editMCQModal'));
            if (modal) modal.hide();
            // Refresh MCQ list if function exists
            if (typeof showMCQManagement === 'function') {
                showMCQManagement();
            }
        } else {
            alert('Error: ' + (result.message || 'Failed to update MCQ.'));
        }
    } catch (error) {
        console.error('Error updating MCQ:', error);
        alert('Failed to update MCQ. Please try again.');
    }
}

// Override existing functions if they exist
if (typeof showAddMCQModal !== 'undefined') {
    showAddMCQModal = showAddMCQModalWithChapter;
}

if (typeof submitMCQ !== 'undefined') {
    submitMCQ = submitMCQWithChapter;
}

if (typeof showEditMCQModal !== 'undefined') {
    showEditMCQModal = showEditMCQModalWithChapter;
}

if (typeof updateMCQ !== 'undefined') {
    updateMCQ = updateMCQWithChapter;
}

// MDCAT Online MCQs - Admin Functions and Management

// Show user management
async function showUserManagement() {
    if (currentUser.role !== 'admin') return;
    
    try {
        showLoading(true);
        
        const response = await fetch('users.php');
        const result = await response.json();
        
        if (result.status === 'success') {
            displayUserManagement(result.data);
        } else {
            showAlert('Failed to load users.', 'danger');
        }
    } catch (error) {
        console.error('Error loading users:', error);
        showAlert('Failed to load users.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Updated displayUserManagement function with view button
function displayUserManagement(users) {
    const contentArea = document.getElementById('content-area');
    
    let html = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-users me-2"></i>User Management</h2>
                <div class="mb-3">
                    <button class="btn btn-primary" onclick="showAddUserModal()">
                        <i class="fas fa-plus me-2"></i>Add New User
                    </button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>Role</th>
                                        <th>Fee Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
    `;
    
    users.forEach(user => {
        html += `
            <tr>
                <td><strong>${user.username}</strong></td>
                <td><span class="badge ${user.role === 'admin' ? 'bg-danger' : 'bg-primary'}">${user.role}</span></td>
                <td>
                    <span class="badge ${user.feePaid ? 'bg-success' : 'bg-warning'} pointer" 
                          onclick="toggleFeeStatus('${user.username}', ${!user.feePaid})">
                        ${user.feePaid ? 'Paid' : 'Pending'}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-info me-1" onclick="viewUser('${user.username}')" title="View User Details">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="editUser('${user.username}', '${user.role}', ${user.feePaid})" title="Edit User">
                        <i class="fas fa-edit"></i>
                    </button>
                    ${user.username !== 'admin' ? `
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteUser('${user.username}')" title="Delete User">
                            <i class="fas fa-trash"></i>
                        </button>
                    ` : ''}
                </td>
            </tr>
        `;
    });
    
    html += `
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    contentArea.innerHTML = html;
}

// New function to view user details
async function viewUser(username) {
    try {
        showLoading(true);
        
        const response = await fetch('users.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'view',
                username: username
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showUserDetailsModal(result.data);
        } else {
            showAlert(result.message || 'Failed to load user details.', 'danger');
        }
    } catch (error) {
        console.error('Error loading user details:', error);
        showAlert('Failed to load user details.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Function to show user details modal
function showUserDetailsModal(user) {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal fade" id="viewUserModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-user me-2"></i>User Details - ${user.username}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <h6 class="mb-0"><i class="fas fa-user-tag me-2"></i>Basic Information</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label class="form-label"><strong>User ID:</strong></label>
                                            <p class="form-control-plaintext">${user.id}</p>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Username:</strong></label>
                                            <p class="form-control-plaintext">${user.username}</p>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Role:</strong></label>
                                            <p class="form-control-plaintext">
                                                <span class="badge ${user.role === 'admin' ? 'bg-danger' : 'bg-primary'}">${user.role}</span>
                                            </p>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Fee Status:</strong></label>
                                            <p class="form-control-plaintext">
                                                <span class="badge ${user.fee_paid ? 'bg-success' : 'bg-warning'}">${user.fee_paid ? 'Paid' : 'Pending'}</span>
                                            </p>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Created At:</strong></label>
                                            <p class="form-control-plaintext">${new Date(user.created_at).toLocaleString()}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <h6 class="mb-0"><i class="fas fa-phone me-2"></i>Contact Information</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label class="form-label"><strong>WhatsApp Number:</strong></label>
                                            <p class="form-control-plaintext">
                                                ${user.whatsapp_number ? 
                                                    `<a href="https://wa.me/${user.whatsapp_number}" target="_blank" class="text-success">
                                                        <i class="fab fa-whatsapp me-1"></i>${user.whatsapp_number}
                                                    </a>` 
                                                    : '<span class="text-muted">Not provided</span>'
                                                }
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <h6 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Purchase Statistics</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Total Notes Purchased:</strong></label>
                                            <p class="form-control-plaintext">
                                                <span class="badge bg-info">${user.total_notes_purchased || 0}</span>
                                            </p>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Total Amount Spent:</strong></label>
                                            <p class="form-control-plaintext">
                                                <span class="badge bg-success">$${user.total_amount_spent || '0.00'}</span>
                                            </p>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Last Purchase Date:</strong></label>
                                            <p class="form-control-plaintext">
                                                ${user.last_purchase_date ? 
                                                    new Date(user.last_purchase_date).toLocaleString() : 
                                                    '<span class="text-muted">No purchases yet</span>'
                                                }
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h6 class="mb-0"><i class="fas fa-key me-2"></i>Security Information</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Password Hash:</strong></label>
                                            <div class="input-group">
                                                <input type="password" class="form-control" id="passwordField" value="${user.password}" readonly>
                                                <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility()">
                                                    <i class="fas fa-eye" id="passwordToggleIcon"></i>
                                                </button>
                                            </div>
                                            <div class="form-text">This is the hashed password stored in the database for security.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="editUser('${user.username}', '${user.role}', ${user.fee_paid})">
                            <i class="fas fa-edit me-2"></i>Edit User
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    new bootstrap.Modal(document.getElementById('viewUserModal')).show();
    
    // Clean up modal when it's hidden
    document.getElementById('viewUserModal').addEventListener('hidden.bs.modal', function () {
        document.body.removeChild(modal);
    });
}

// Function to toggle password visibility in the modal
function togglePasswordVisibility() {
    const passwordField = document.getElementById('passwordField');
    const toggleIcon = document.getElementById('passwordToggleIcon');
    
    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    } else {
        passwordField.type = 'password';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    }
}

// Show add user modal
function showAddUserModal() {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal fade" id="addUserModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Add New User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addUserForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-header">
                                            <h6 class="mb-0"><i class="fas fa-user-tag me-2"></i>Basic Information</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <label class="form-label"><strong>Username:</strong> <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" id="add-username" placeholder="Enter username" required>
                                                <div class="form-text">Username must be at least 3 characters long</div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label"><strong>Password:</strong> <span class="text-danger">*</span></label>
                                                <input type="password" class="form-control" id="add-password" placeholder="Enter password" required>
                                                <div class="form-text">Password must be at least 6 characters long</div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label"><strong>Role:</strong></label>
                                                <select class="form-control" id="add-role">
                                                    <option value="user">User</option>
                                                    <option value="admin">Admin</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-header">
                                            <h6 class="mb-0"><i class="fas fa-phone me-2"></i>Contact & Status</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <label class="form-label"><strong>WhatsApp Number:</strong> <span class="text-danger">*</span></label>
                                                <input type="tel" class="form-control" id="add-whatsapp" placeholder="03XXXXXXXXX" required>
                                                <div class="form-text">Pakistani format: 03XXXXXXXXX (11 digits)</div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label"><strong>Fee Status:</strong></label>
                                                <select class="form-control" id="add-fee-status">
                                                    <option value="1">Paid</option>
                                                    <option value="0">Pending</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="submitAddUser()">
                            <i class="fas fa-plus me-2"></i>Add User
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    new bootstrap.Modal(document.getElementById('addUserModal')).show();
    
    // Clean up modal when it's hidden
    document.getElementById('addUserModal').addEventListener('hidden.bs.modal', function () {
        document.body.removeChild(modal);
    });
}
// Submit add user form
async function submitAddUser() {
    const username = document.getElementById('add-username').value.trim();
    const password = document.getElementById('add-password').value.trim();
    const whatsapp = document.getElementById('add-whatsapp').value.trim();
    const role = document.getElementById('add-role').value;
    const feePaid = parseInt(document.getElementById('add-fee-status').value);
    
    // Validation
    if (!username || !password || !whatsapp) {
        showAlert('Please fill all required fields.', 'warning');
        return;
    }
    
    if (username.length < 3) {
        showAlert('Username must be at least 3 characters long.', 'warning');
        return;
    }
    
    if (password.length < 6) {
        showAlert('Password must be at least 6 characters long.', 'warning');
        return;
    }
    
    // Validate WhatsApp number format (Pakistani format)
    if (!whatsapp.match(/^03[0-9]{9}$/)) {
        showAlert('Invalid WhatsApp number format. Please use Pakistani format (03XXXXXXXXX)', 'warning');
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('users.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'add',
                username: username,
                password: password,
                whatsapp_number: whatsapp,
                role: role,
                feePaid: feePaid
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert('User added successfully!', 'success');
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('addUserModal'));
            if (modal) modal.hide();
            // Refresh user list
            showUserManagement();
        } else {
            showAlert(result.message || 'Failed to add user.', 'danger');
        }
    } catch (error) {
        console.error('Error adding user:', error);
        showAlert('Failed to add user.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Add user
async function addUser(username, password, role, feePaid, whatsapp_number = '') {
    try {
        showLoading(true);
        
        const response = await fetch('users.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'add',
                username: username,
                password: password,
                role: role,
                feePaid: feePaid,
                whatsapp_number: whatsapp_number
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert('User added successfully!', 'success');
            showUserManagement(); // Refresh list
        } else {
            showAlert(result.message || 'Failed to add user.', 'danger');
        }
    } catch (error) {
        console.error('Error adding user:', error);
        showAlert('Failed to add user.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Edit user
function editUser(username, currentRole, currentFeePaid) {
    const newRole = confirm(`Change role? Current: ${currentRole}. Click OK for admin, Cancel for user.`) ? 'admin' : 'user';
    const newPassword = prompt('Enter new password (leave empty to keep current):');
    
    updateUser(username, newPassword, newRole, currentFeePaid);
}

// Update user
async function updateUser(username, password, role, feePaid) {
    try {
        showLoading(true);
        
        const requestData = {
            action: 'edit',
            username: username,
            role: role,
            feePaid: feePaid
        };
        
        if (password) {
            requestData.password = password;
        }
        
        const response = await fetch('users.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestData)
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert('User updated successfully!', 'success');
            showUserManagement(); // Refresh list
        } else {
            showAlert(result.message || 'Failed to update user.', 'danger');
        }
    } catch (error) {
        console.error('Error updating user:', error);
        showAlert('Failed to update user.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Toggle fee status
async function toggleFeeStatus(username, newStatus) {
    try {
        const response = await fetch('users.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'toggle_fee',
                username: username,
                feePaid: newStatus
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showUserManagement(); // Refresh list
        } else {
            showAlert(result.message || 'Failed to update fee status.', 'danger');
        }
    } catch (error) {
        console.error('Error updating fee status:', error);
        showAlert('Failed to update fee status.', 'danger');
    }
}

// Delete user
async function deleteUser(username) {
    if (!confirm(`Are you sure you want to delete user "${username}"?`)) {
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('users.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'delete',
                username: username
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert('User deleted successfully!', 'success');
            showUserManagement(); // Refresh list
        } else {
            showAlert(result.message || 'Failed to delete user.', 'danger');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showAlert('Failed to delete user.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Show MCQ management
async function showMCQManagement() {
    if (currentUser.role !== 'admin') return;
    
    try {
        showLoading(true);
        
        const response = await fetch('mcq.php?type=regular');
        const result = await response.json();
        
        if (result.status === 'success') {
            displayMCQManagement(result.data);
        } else {
            showAlert('Failed to load MCQs.', 'danger');
        }
    } catch (error) {
        console.error('Error loading MCQs:', error);
        showAlert('Failed to load MCQs.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Display MCQ management
function displayMCQManagement(mcqs) {
    const contentArea = document.getElementById('content-area');
    
    let html = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-question-circle me-2"></i>MCQ Management</h2>
                <div class="mb-3">
                    <button class="btn btn-primary me-2" onclick="showAddMCQModal()">
                        <i class="fas fa-plus me-2"></i>Add MCQ
                    </button>
                    <button class="btn btn-success" onclick="showSampleMCQs()">
                        <i class="fas fa-eye me-2"></i>View Sample MCQs
                    </button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Question</th>
                                        <th>Category</th>
                                        <th>Created By</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
    `;
    
    mcqs.forEach(mcq => {
        const questionPreview = mcq.question.length > 50 ? mcq.question.substring(0, 50) + '...' : mcq.question;
        
        html += `
            <tr>
                <td><strong>#${mcq.id}</strong></td>
                <td>${questionPreview}</td>
                <td><span class="badge bg-info">${mcq.category}</span></td>
                <td>${mcq.createdBy}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="viewMCQ(${mcq.id})">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-success me-1" onclick="editMCQ(${mcq.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteMCQ(${mcq.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += `
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    contentArea.innerHTML = html;
}

// Show sample MCQs
async function showSampleMCQs() {
    try {
        showLoading(true);
        
        const response = await fetch('mcq.php?type=sample');
        const result = await response.json();
        
        if (result.status === 'success') {
            displaySampleMCQs(result.data);
        } else {
            showAlert('No sample MCQs found.', 'info');
        }
    } catch (error) {
        console.error('Error loading sample MCQs:', error);
        showAlert('Failed to load sample MCQs.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Display sample MCQs
function displaySampleMCQs(mcqs) {
    const contentArea = document.getElementById('content-area');
    
    let html = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-eye me-2"></i>Sample MCQs (Demo Questions)</h2>
                <div class="mb-3">
                    <button class="btn btn-outline-secondary" onclick="showMCQManagement()">
                        <i class="fas fa-arrow-left me-2"></i>Back to MCQ Management
                    </button>
                    <button class="btn btn-primary ms-2" onclick="showAddSampleMCQModal()">
                        <i class="fas fa-plus me-2"></i>Add Sample MCQ
                    </button>
                </div>
            </div>
        </div>
    `;
    
    if (mcqs.length === 0) {
        html += `
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-question-circle fa-3x text-muted mb-3"></i>
                            <h5>No Sample MCQs</h5>
                            <p class="text-muted">Add some sample questions for demo tests.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    } else {
        html += `
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Question</th>
                                            <th>Category</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
        `;
        
        mcqs.forEach(mcq => {
            const questionPreview = mcq.question.length > 50 ? mcq.question.substring(0, 50) + '...' : mcq.question;
            
            html += `
                <tr>
                    <td><strong>#${mcq.id}</strong></td>
                    <td>${questionPreview}</td>
                    <td><span class="badge bg-info">${mcq.category}</span></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary me-1" onclick="viewMCQ(${mcq.id}, 'sample')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteMCQ(${mcq.id}, 'sample')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
        
        html += `
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    contentArea.innerHTML = html;
}

// Show code management (Admin only)
async function showCodeManagement() {
    if (!currentUser || currentUser.role !== 'admin') {
        showAlert('Access denied. Admin privileges required.', 'danger');
        return;
    }
    
    try {
        showLoading(true);
        
        // Load both registration and approval codes
        const [regResponse, appResponse] = await Promise.all([
            fetch('codes.php?action=registration'),
            fetch('codes.php?action=approval')
        ]);
        
        const regResult = await regResponse.json();
        const appResult = await appResponse.json();
        
        if (regResult.status === 'success' && appResult.status === 'success') {
            displayCodeManagement(regResult.data, appResult.data);
        } else {
            showAlert('Failed to load codes.', 'danger');
        }
    } catch (error) {
        console.error('Error loading codes:', error);
        showAlert('Failed to load codes.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Display code management interface
function displayCodeManagement(registrationCodes, approvalCodes) {
    const contentArea = document.getElementById('content-area');
    
    let html = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-key me-2"></i>Code Management</h2>
            </div>
        </div>
        
        <!-- Registration Codes Section -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-user-plus me-2"></i>Registration Codes</h5>
                        <button class="btn btn-primary btn-sm" onclick="showAddCodeModal('registration')">
                            <i class="fas fa-plus me-2"></i>Add Code
                        </button>
                    </div>
                    <div class="card-body">
                        <p class="text-muted">These codes allow new users to register. Each code can only be used once.</p>
                        ${registrationCodes.length === 0 ? 
                            '<div class="alert alert-info">No registration codes available.</div>' :
                            `<div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${registrationCodes.map(code => `
                                            <tr>
                                                <td><strong>${code}</strong></td>
                                                <td><span class="badge bg-success">Available</span></td>
                                                <td>
                                                    <button class="btn btn-sm btn-outline-danger" onclick="deleteCode('${code}', 'registration')">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>`
                        }
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Approval Codes Section -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-check-circle me-2"></i>Approval Codes</h5>
                        <button class="btn btn-success btn-sm" onclick="showAddCodeModal('approval')">
                            <i class="fas fa-plus me-2"></i>Add Code
                        </button>
                    </div>
                    <div class="card-body">
                        <p class="text-muted">These codes are used for special approvals or features.</p>
                        ${approvalCodes.length === 0 ? 
                            '<div class="alert alert-info">No approval codes available.</div>' :
                            `<div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${approvalCodes.map(code => `
                                            <tr>
                                                <td><strong>${code}</strong></td>
                                                <td><span class="badge bg-primary">Active</span></td>
                                                <td>
                                                    <button class="btn btn-sm btn-outline-danger" onclick="deleteCode('${code}', 'approval')">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>`
                        }
                    </div>
                </div>
            </div>
        </div>
    `;
    
    contentArea.innerHTML = html;
}

// Show add code modal
function showAddCodeModal(type) {
    const codeType = type === 'registration' ? 'Registration' : 'Approval';
    const code = prompt(`Enter new ${codeType} code:`);
    
    if (code && code.trim()) {
        addCode(code.trim(), type);
    }
}

// Add new code
async function addCode(code, type) {
    try {
        showLoading(true);
        
        const response = await fetch('codes.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: type,
                code: code
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert(`${type === 'registration' ? 'Registration' : 'Approval'} code added successfully!`, 'success');
            showCodeManagement(); // Refresh the display
        } else {
            showAlert(result.message || 'Failed to add code.', 'danger');
        }
    } catch (error) {
        console.error('Error adding code:', error);
        showAlert('Failed to add code.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Delete code
async function deleteCode(code, type) {
    if (!confirm(`Are you sure you want to delete this ${type} code: "${code}"?`)) {
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('codes.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'delete',
                code: code,
                type: type
            })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert('Code deleted successfully!', 'success');
            showCodeManagement(); // Refresh the display
        } else {
            showAlert(result.message || 'Failed to delete code.', 'danger');
        }
    } catch (error) {
        console.error('Error deleting code:', error);
        showAlert('Failed to delete code.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Show add MCQ modal
function showAddMCQModal() {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal fade" id="addMCQModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New MCQ</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addMCQForm">
                            <div class="mb-3">
                                <label class="form-label">Question:</label>
                                <textarea class="form-control" id="mcq-question" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Category:</label>
                                <select class="form-control" id="mcq-category" required>
                                    <option value="">Select Category</option>
                                    <option value="Physics">Physics</option>
                                    <option value="Chemistry">Chemistry</option>
                                    <option value="Biology">Biology</option>
                                    <option value="English">English</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option A:</label>
                                <input type="text" class="form-control" id="mcq-option-a" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option B:</label>
                                <input type="text" class="form-control" id="mcq-option-b" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option C:</label>
                                <input type="text" class="form-control" id="mcq-option-c" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option D:</label>
                                <input type="text" class="form-control" id="mcq-option-d" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Correct Answer:</label>
                                <select class="form-control" id="mcq-answer" required>
                                    <option value="">Select Correct Answer</option>
                                    <option value="0">A</option>
                                    <option value="1">B</option>
                                    <option value="2">C</option>
                                    <option value="3">D</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="submitMCQ()">Add MCQ</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    new bootstrap.Modal(document.getElementById('addMCQModal')).show();
}

// Submit MCQ
async function submitMCQ() {
    const question = document.getElementById('mcq-question').value.trim();
    const category = document.getElementById('mcq-category').value;
    const optionA = document.getElementById('mcq-option-a').value.trim();
    const optionB = document.getElementById('mcq-option-b').value.trim();
    const optionC = document.getElementById('mcq-option-c').value.trim();
    const optionD = document.getElementById('mcq-option-d').value.trim();
    const answer = parseInt(document.getElementById('mcq-answer').value);

    if (!question || !category || !optionA || !optionB || !optionC || !optionD || isNaN(answer)) {
        showAlert('Please fill all fields.', 'warning');
        return;
    }

    try {
        showLoading(true);
        
        const response = await fetch('mcq.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                question: question,
                options: [optionA, optionB, optionC, optionD],
                answer: answer,
                category: category,
                type: 'regular',
                username: currentUser.username
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            showAlert('MCQ added successfully!', 'success');
            bootstrap.Modal.getInstance(document.getElementById('addMCQModal')).hide();
            showMCQManagement(); // Refresh list
        } else {
            showAlert(result.message || 'Failed to add MCQ.', 'danger');
        }
    } catch (error) {
        console.error('Error adding MCQ:', error);
        showAlert('Failed to add MCQ.', 'danger');
    } finally {
        showLoading(false);
    }
}

// View MCQ
async function viewMCQ(mcqId, type = 'regular') {
    try {
        showLoading(true);
        
        const response = await fetch(`mcq.php?type=${type}`);
        const result = await response.json();
        
        if (result.status === 'success') {
            const mcq = result.data.find(m => m.id === mcqId);
            if (mcq) {
                showMCQDetails(mcq);
            } else {
                showAlert('MCQ not found.', 'danger');
            }
        } else {
            showAlert('Failed to load MCQ.', 'danger');
        }
    } catch (error) {
        console.error('Error loading MCQ:', error);
        showAlert('Failed to load MCQ.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Show MCQ details
function showMCQDetails(mcq) {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal fade" id="viewMCQModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">MCQ Details - #${mcq.id}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <strong>Question:</strong>
                            <p>${mcq.question}</p>
                        </div>
                        <div class="mb-3">
                            <strong>Options:</strong>
                            <ul>
                                ${mcq.options.map((option, index) => `
                                    <li ${index === mcq.answer ? 'class="text-success fw-bold"' : ''}>${String.fromCharCode(65 + index)}. ${option} ${index === mcq.answer ? '(Correct)' : ''}</li>
                                `).join('')}
                            </ul>
                        </div>
                        <div class="mb-3">
                            <strong>Category:</strong> <span class="badge bg-info">${mcq.category}</span>
                        </div>
                        <div class="mb-3">
                            <strong>Created By:</strong> ${mcq.createdBy}
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    new bootstrap.Modal(document.getElementById('viewMCQModal')).show();
}

// Edit MCQ
async function editMCQ(mcqId) {
    try {
        showLoading(true);
        
        const response = await fetch('mcq.php?type=regular');
        const result = await response.json();
        
        if (result.status === 'success') {
            const mcq = result.data.find(m => m.id === mcqId);
            if (mcq) {
                showEditMCQModal(mcq);
            } else {
                showAlert('MCQ not found.', 'danger');
            }
        } else {
            showAlert('Failed to load MCQ.', 'danger');
        }
    } catch (error) {
        console.error('Error loading MCQ:', error);
        showAlert('Failed to load MCQ.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Show edit MCQ modal
function showEditMCQModal(mcq) {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal fade" id="editMCQModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit MCQ - #${mcq.id}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="editMCQForm">
                            <input type="hidden" id="edit-mcq-id" value="${mcq.id}">
                            <div class="mb-3">
                                <label class="form-label">Question:</label>
                                <textarea class="form-control" id="edit-mcq-question" rows="3" required>${mcq.question}</textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Category:</label>
                                <select class="form-control" id="edit-mcq-category" required>
                                    <option value="Physics" ${mcq.category === 'Physics' ? 'selected' : ''}>Physics</option>
                                    <option value="Chemistry" ${mcq.category === 'Chemistry' ? 'selected' : ''}>Chemistry</option>
                                    <option value="Biology" ${mcq.category === 'Biology' ? 'selected' : ''}>Biology</option>
                                    <option value="English" ${mcq.category === 'English' ? 'selected' : ''}>English</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option A:</label>
                                <input type="text" class="form-control" id="edit-mcq-option-a" value="${mcq.options[0]}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option B:</label>
                                <input type="text" class="form-control" id="edit-mcq-option-b" value="${mcq.options[1]}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option C:</label>
                                <input type="text" class="form-control" id="edit-mcq-option-c" value="${mcq.options[2]}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option D:</label>
                                <input type="text" class="form-control" id="edit-mcq-option-d" value="${mcq.options[3]}" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Correct Answer:</label>
                                <select class="form-control" id="edit-mcq-answer" required>
                                    <option value="0" ${mcq.answer === 0 ? 'selected' : ''}>A</option>
                                    <option value="1" ${mcq.answer === 1 ? 'selected' : ''}>B</option>
                                    <option value="2" ${mcq.answer === 2 ? 'selected' : ''}>C</option>
                                    <option value="3" ${mcq.answer === 3 ? 'selected' : ''}>D</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="updateMCQ()">Update MCQ</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    new bootstrap.Modal(document.getElementById('editMCQModal')).show();
}

// Update MCQ - Fixed for InfinityFree
async function updateMCQ() {
    const id = parseInt(document.getElementById('edit-mcq-id').value);
    const question = document.getElementById('edit-mcq-question').value.trim();
    const category = document.getElementById('edit-mcq-category').value;
    const optionA = document.getElementById('edit-mcq-option-a').value.trim();
    const optionB = document.getElementById('edit-mcq-option-b').value.trim();
    const optionC = document.getElementById('edit-mcq-option-c').value.trim();
    const optionD = document.getElementById('edit-mcq-option-d').value.trim();
    const answer = parseInt(document.getElementById('edit-mcq-answer').value);

    if (!question || !category || !optionA || !optionB || !optionC || !optionD || isNaN(answer)) {
        showAlert('Please fill all fields.', 'warning');
        return;
    }

    try {
        showLoading(true);
        
        const response = await fetch('mcq.php', {
            method: 'POST',  // Changed from PUT to POST
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'update',  // Added action parameter
                id: id,
                question: question,
                options: [optionA, optionB, optionC, optionD],
                answer: answer,
                category: category,
                username: currentUser.username
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            showAlert('MCQ updated successfully!', 'success');
            bootstrap.Modal.getInstance(document.getElementById('editMCQModal')).hide();
            showMCQManagement(); // Refresh list
        } else {
            showAlert(result.message || 'Failed to update MCQ.', 'danger');
        }
    } catch (error) {
        console.error('Error updating MCQ:', error);
        showAlert('Failed to update MCQ.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Delete MCQ - Fixed for InfinityFree
async function deleteMCQ(mcqId, type = 'regular') {
    if (!confirm('Are you sure you want to delete this MCQ?')) {
        return;
    }

    try {
        showLoading(true);
        
        const response = await fetch('mcq.php', {
            method: 'POST',  // Changed from DELETE to POST
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'delete',  // Added action parameter
                id: mcqId
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            showAlert('MCQ deleted successfully!', 'success');
            if (type === 'sample') {
                showSampleMCQs(); // Refresh sample MCQs
            } else {
                showMCQManagement(); // Refresh regular MCQs
            }
        } else {
            showAlert(result.message || 'Failed to delete MCQ.', 'danger');
        }
    } catch (error) {
        console.error('Error deleting MCQ:', error);
        showAlert('Failed to delete MCQ.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Show add sample MCQ modal
function showAddSampleMCQModal() {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal fade" id="addSampleMCQModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Sample MCQ (Demo)</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addSampleMCQForm">
                            <div class="mb-3">
                                <label class="form-label">Question:</label>
                                <textarea class="form-control" id="sample-mcq-question" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Category:</label>
                                <select class="form-control" id="sample-mcq-category" required>
                                    <option value="">Select Category</option>
                                    <option value="Physics">Physics</option>
                                    <option value="Chemistry">Chemistry</option>
                                    <option value="Biology">Biology</option>
                                    <option value="English">English</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option A:</label>
                                <input type="text" class="form-control" id="sample-mcq-option-a" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option B:</label>
                                <input type="text" class="form-control" id="sample-mcq-option-b" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option C:</label>
                                <input type="text" class="form-control" id="sample-mcq-option-c" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Option D:</label>
                                <input type="text" class="form-control" id="sample-mcq-option-d" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Correct Answer:</label>
                                <select class="form-control" id="sample-mcq-answer" required>
                                    <option value="">Select Correct Answer</option>
                                    <option value="0">A</option>
                                    <option value="1">B</option>
                                    <option value="2">C</option>
                                    <option value="3">D</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="submitSampleMCQ()">Add Sample MCQ</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    new bootstrap.Modal(document.getElementById('addSampleMCQModal')).show();
}

// Submit sample MCQ
async function submitSampleMCQ() {
    const question = document.getElementById('sample-mcq-question').value.trim();
    const category = document.getElementById('sample-mcq-category').value;
    const optionA = document.getElementById('sample-mcq-option-a').value.trim();
    const optionB = document.getElementById('sample-mcq-option-b').value.trim();
    const optionC = document.getElementById('sample-mcq-option-c').value.trim();
    const optionD = document.getElementById('sample-mcq-option-d').value.trim();
    const answer = parseInt(document.getElementById('sample-mcq-answer').value);

    if (!question || !category || !optionA || !optionB || !optionC || !optionD || isNaN(answer)) {
        showAlert('Please fill all fields.', 'warning');
        return;
    }

    try {
        showLoading(true);
        
        const response = await fetch('mcq.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                question: question,
                options: [optionA, optionB, optionC, optionD],
                answer: answer,
                category: category,
                type: 'sample',
                username: currentUser.username
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            showAlert('Sample MCQ added successfully!', 'success');
            bootstrap.Modal.getInstance(document.getElementById('addSampleMCQModal')).hide();
            showSampleMCQs(); // Refresh sample MCQs list
        } else {
            showAlert(result.message || 'Failed to add sample MCQ.', 'danger');
        }
    } catch (error) {
        console.error('Error adding sample MCQ:', error);
        showAlert('Failed to add sample MCQ.', 'danger');
    } finally {
        showLoading(false);
    }
}