 // MDCAT Online MCQs - Core Application Logic
// Global Variables
let currentUser = null;
let currentTest = null;
let testMCQs = [];
let userAnswers = [];
let currentQuestionIndex = 0;
let testTimer = null;
let testTimeRemaining = 0;

// Initialize application when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Initialize the application
function initializeApp() {
    // Bind event listeners
    bindEventListeners();
    
    // Check if user is already logged in (session storage fallback)
    const savedUser = sessionStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        showMainApp();
    } else {
        showLandingPage();
    }
}

// Bind all event listeners
function bindEventListeners() {
    // Landing page buttons
    const demoTestBtn = document.getElementById('demo-test-btn');
    const loginAccessBtn = document.getElementById('login-access-btn');
    const backToLandingBtn = document.getElementById('back-to-landing');
    
    if (demoTestBtn) {
        demoTestBtn.addEventListener('click', showDemoTestModal);
    }
    if (loginAccessBtn) {
        loginAccessBtn.addEventListener('click', showLoginContainer);
    }
    if (backToLandingBtn) {
        backToLandingBtn.addEventListener('click', showLandingPage);
    }

    // Demo test modal
    const startDemoBtn = document.getElementById('start-demo-btn');
    if (startDemoBtn) {
        startDemoBtn.addEventListener('click', startDemoTest);
    }

    // Login form
    const loginBtn = document.getElementById('login-btn');
    const registerBtn = document.getElementById('register-btn');
    const loginForm = document.getElementById('login-password');
    
    if (loginBtn) {
        loginBtn.addEventListener('click', handleLogin);
    }
    if (registerBtn) {
        registerBtn.addEventListener('click', handleRegister);
    }
    if (loginForm) {
        loginForm.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                handleLogin();
            }
        });
    }

    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }

    // Category filter
    const applyFilterBtn = document.getElementById('apply-category-filter');
    if (applyFilterBtn) {
        applyFilterBtn.addEventListener('click', applyCategoryFilter);
    }
}

// Show landing page
function showLandingPage() {
    hideAll();
    document.getElementById('landing-page').style.display = 'block';
}

// Show login container
function showLoginContainer() {
    hideAll();
    document.getElementById('login-container').style.display = 'block';
}

// Show main application
function showMainApp() {
    hideAll();
    document.getElementById('main-app').style.display = 'block';
    
    // Update user display
    const userDisplay = document.getElementById('current-user-display');
    if (userDisplay && currentUser) {
        userDisplay.textContent = `Welcome, ${currentUser.username} (${currentUser.role})`;
    }

    // Generate navigation based on user role
    generateNavigation();
    
    // Show dashboard by default
    showDashboard();
}

// Hide all main containers
function hideAll() {
    document.getElementById('landing-page').style.display = 'none';
    document.getElementById('login-container').style.display = 'none';
    document.getElementById('main-app').style.display = 'none';
}

// Show demo test modal
function showDemoTestModal() {
    const modal = new bootstrap.Modal(document.getElementById('demoTestModal'));
    modal.show();
}

// Start demo test - Fixed version
async function startDemoTest() {
    try {
        showLoading(true);
        
        // First check if demo is available
        const checkResponse = await fetch('demo_check.php');
        const checkResult = await checkResponse.json();
        
        if (!checkResult.available) {
            showAlert('Demo test is not available at the moment. Not enough questions in database.', 'warning');
            return;
        }
        
        // Close the modal properly
        const demoModal = bootstrap.Modal.getInstance(document.getElementById('demoTestModal'));
        if (demoModal) {
            demoModal.hide();
        }
        
        // Small delay to ensure modal is fully closed
        setTimeout(() => {
            // Redirect to load_demo.php which will prepare questions and redirect to demo.php
            window.location.href = 'load_demo.php';
        }, 300);
        
    } catch (error) {
        console.error('Error starting demo test:', error);
        showAlert('Failed to start demo test. Please try again.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Create demo questions if none available from backend
function createDemoQuestions() {
    return [
        {
            id: 'demo1',
            question: 'What is the SI unit of force?',
            options: ['Joule', 'Newton', 'Watt', 'Pascal'],
            answer: 1,
            category: 'Physics'
        },
        {
            id: 'demo2',
            question: 'Which element has the chemical symbol "O"?',
            options: ['Gold', 'Silver', 'Oxygen', 'Iron'],
            answer: 2,
            category: 'Chemistry'
        },
        {
            id: 'demo3',
            question: 'What is the powerhouse of the cell?',
            options: ['Nucleus', 'Ribosome', 'Mitochondria', 'Cytoplasm'],
            answer: 2,
            category: 'Biology'
        },
        {
            id: 'demo4',
            question: 'What is the past tense of "go"?',
            options: ['Goed', 'Gone', 'Went', 'Going'],
            answer: 2,
            category: 'English'
        },
        {
            id: 'demo5',
            question: 'What is 15 + 27?',
            options: ['41', '42', '43', '44'],
            answer: 1,
            category: 'Physics'
        }
    ];
}

// Handle login
async function handleLogin() {
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value.trim();
    const loginBtn = document.getElementById('login-btn');
    const errorDiv = document.getElementById('login-error');

    if (!username || !password) {
        showLoginError('Please enter both username and password');
        return;
    }

    // Show loading state
    loginBtn.querySelector('.loading').classList.add('show');
    loginBtn.disabled = true;
    errorDiv.style.display = 'none';

    try {
        const response = await fetch('auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'login',
                username: username,
                password: password
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            currentUser = result.data;
            sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
            showMainApp();
        } else {
            showLoginError(result.message || 'Login failed');
        }
    } catch (error) {
        console.error('Login error:', error);
        showLoginError('Connection error. Please try again.');
    } finally {
        loginBtn.querySelector('.loading').classList.remove('show');
        loginBtn.disabled = false;
    }
}

// Handle registration with a compact mobile-friendly form
async function handleRegister() {
    // Create a backdrop with subtle animation
    const backdrop = document.createElement('div');
    backdrop.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(47, 56, 69, 0.85);
        backdrop-filter: blur(8px);
        z-index: 9998;
        opacity: 0;
        transition: all 0.3s ease;
    `;
    
    // Create the compact form
    const form = document.createElement('form');
    form.innerHTML = `
        <div class="form-container">
            <div class="form-header">
                <div class="logo-section">
                    <div class="logo-icon">
                        <img src="../logo.png" alt="NayaRasta Logo" class="nayarasta-logo">
                    </div>
                    <div class="brand-text">
                        <h2>NAYARASTA</h2>
                        <p>Create Account</p>
                    </div>
                </div>
                <button type="button" id="closeBtn" class="close-btn">×</button>
            </div>
            
            <div class="form-body">
                <div class="input-group">
                    <label for="regUsername">Username</label>
                    <div class="input-container">
                        <svg class="input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                        <input type="text" id="regUsername" placeholder="Enter username" required>
                    </div>
                </div>
                
                <div class="input-group">
                    <label for="regWhatsapp">Number</label>
                    <div class="input-container">
                        <svg class="input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        <input type="tel" id="regWhatsapp" placeholder="03XXXXXXXXX" pattern="[0-9]{11}" required>
                        <div class="country-prefix">+92</div>
                    </div>
                </div>
                
                <div class="input-group">
                    <label for="regPassword">Password</label>
                    <div class="input-container password-container">
                        <svg class="input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <circle cx="12" cy="16" r="1"></circle>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                        <input type="password" id="regPassword" placeholder="Enter password" required>
                        <button type="button" id="togglePassword" class="toggle-password">
                            <svg class="eye-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>
                </div>
                
                <input type="hidden" id="registrationCode" value="NEWUSER">
                
                <div class="info-box">
                    <p><strong>Free Registration!</strong> Contact: <strong>03328335332</strong></p>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="register-btn">
                        <span class="btn-text">Create Account</span>
                        <span class="btn-loader" style="display: none;">
                            <svg class="spinner" width="16" height="16" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none" opacity="0.3"/>
                                <path d="M14,2 A12,12 0 0,1 22,12" stroke="currentColor" stroke-width="4" fill="none"/>
                            </svg>
                            Creating...
                        </span>
                    </button>
                    <button type="button" id="cancelRegister" class="cancel-btn">Cancel</button>
                </div>
            </div>
        </div>
    `;

    // Compact mobile-friendly styling
    form.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.9);
        width: 95%;
        max-width: 400px;
        max-height: 90vh;
        overflow-y: auto;
        z-index: 9999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        opacity: 0;
        transition: all 0.3s ease;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    `;

    // Compact CSS styles
    const styles = document.createElement('style');
    styles.textContent = `
        .form-container {
            background: #ffffff;
            border-radius: 12px;
            overflow: hidden;
        }
        
        .form-header {
            background: linear-gradient(135deg, #2f3845 0%, #3a4553 100%);
            color: white;
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .logo-section {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo-icon {
            width: 36px;
            height: 36px;
        }
        
        .nayarasta-logo {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .brand-text h2 {
            margin: 0;
            font-size: 16px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        
        .brand-text p {
            margin: 2px 0 0 0;
            font-size: 11px;
            opacity: 0.8;
        }
        
        .close-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s ease;
        }
        
        .close-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .form-body {
            padding: 20px;
        }
        
        .input-group {
            margin-bottom: 16px;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: #2f3845;
            font-size: 13px;
        }
        
        .input-container {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #718096;
            z-index: 1;
        }
        
        .input-group input {
            width: 100%;
            padding: 12px 12px 12px 40px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s ease;
            box-sizing: border-box;
            background: #ffffff;
            color: #2f3845;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: #2f3845;
            box-shadow: 0 0 0 3px rgba(47, 56, 69, 0.1);
        }
        
        .input-group input::placeholder {
            color: #a0aec0;
            font-size: 13px;
        }
        
        .country-prefix {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(47, 56, 69, 0.1);
            color: #2f3845;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .password-container input {
            padding-right: 50px;
        }
        
        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #718096;
            padding: 6px;
            border-radius: 4px;
            transition: color 0.2s ease;
        }
        
        .toggle-password:hover {
            color: #2f3845;
        }
        
        .info-box {
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 12px;
            margin: 16px 0;
            text-align: center;
        }
        
        .info-box p {
            margin: 0;
            font-size: 13px;
            color: #4a5568;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .register-btn {
            flex: 1;
            background: linear-gradient(135deg, #2f3845 0%, #4a5568 100%);
            color: white;
            border: none;
            padding: 14px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
        }
        
        .register-btn:hover:not(:disabled) {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(47, 56, 69, 0.3);
        }
        
        .register-btn:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }
        
        .btn-loader {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .spinner {
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .cancel-btn {
            background: #ffffff;
            color: #718096;
            border: 2px solid #e2e8f0;
            padding: 14px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .cancel-btn:hover {
            background: #f7fafc;
            border-color: #cbd5e0;
            color: #4a5568;
        }
        
        /* Mobile responsiveness */
        @media (max-width: 480px) {
            .form-header {
                padding: 14px 16px;
            }
            
            .form-body {
                padding: 16px;
            }
            
            .logo-icon {
                width: 32px;
                height: 32px;
            }
            
            .brand-text h2 {
                font-size: 14px;
            }
            
            .button-group {
                flex-direction: column;
                gap: 8px;
            }
            
            .input-group {
                margin-bottom: 14px;
            }
        }
        
        /* Ensure form stays within viewport */
        @media (max-height: 600px) {
            .form-body {
                padding: 16px;
            }
            
            .input-group {
                margin-bottom: 12px;
            }
            
            .info-box {
                margin: 12px 0;
                padding: 10px;
            }
        }
    `;

    document.head.appendChild(styles);
    document.body.appendChild(backdrop);
    document.body.appendChild(form);

    // Animate in
    requestAnimationFrame(() => {
        backdrop.style.opacity = '1';
        setTimeout(() => {
            form.style.opacity = '1';
            form.style.transform = 'translate(-50%, -50%) scale(1)';
        }, 50);
    });

    // WhatsApp number validation
    const whatsappInput = form.querySelector('#regWhatsapp');
    whatsappInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        
        if (value.length > 11) {
            value = value.slice(0, 11);
        }
        
        if (value.length > 0 && !value.startsWith('03')) {
            if (value.startsWith('3')) {
                value = '0' + value;
            } else if (!value.startsWith('0')) {
                value = '03' + value;
            }
        }
        
        e.target.value = value;
        
        if (value.length === 11 && value.startsWith('03')) {
            e.target.style.borderColor = '#48bb78';
        } else {
            e.target.style.borderColor = '#e2e8f0';
        }
    });

    // Password toggle
    const passwordInput = form.querySelector('#regPassword');
    const toggleBtn = form.querySelector('#togglePassword');
    const eyeIcon = toggleBtn.querySelector('.eye-icon');
    
    toggleBtn.addEventListener('click', () => {
        const isPassword = passwordInput.type === 'password';
        passwordInput.type = isPassword ? 'text' : 'password';
        
        if (isPassword) {
            eyeIcon.innerHTML = `
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                <line x1="1" y1="1" x2="23" y2="23"></line>
            `;
        } else {
            eyeIcon.innerHTML = `
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                <circle cx="12" cy="12" r="3"></circle>
            `;
        }
    });

    // Close handlers
    const closeForm = () => {
        form.style.opacity = '0';
        form.style.transform = 'translate(-50%, -50%) scale(0.9)';
        backdrop.style.opacity = '0';
        
        setTimeout(() => {
            if (document.body.contains(form)) document.body.removeChild(form);
            if (document.body.contains(backdrop)) document.body.removeChild(backdrop);
            if (document.head.contains(styles)) document.head.removeChild(styles);
        }, 300);
    };

    form.querySelector('#closeBtn').addEventListener('click', closeForm);
    form.querySelector('#cancelRegister').addEventListener('click', closeForm);
    backdrop.addEventListener('click', (e) => {
        if (e.target === backdrop) closeForm();
    });

    // Submit handler
    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        
        const username = document.getElementById('regUsername').value.trim();
        const whatsapp = document.getElementById('regWhatsapp').value.trim();
        const password = document.getElementById('regPassword').value.trim();
        const registrationCode = "NEWUSER";
        const submitBtn = form.querySelector('.register-btn');
        const btnText = submitBtn.querySelector('.btn-text');
        const btnLoader = submitBtn.querySelector('.btn-loader');

        // Validation
        if (!username || !password || !whatsapp) {
            showAlert && showAlert('All fields are required', 'warning');
            return;
        }

        if (whatsapp.length !== 11 || !whatsapp.startsWith('03')) {
            showAlert && showAlert('Please enter a valid Pakistani WhatsApp number', 'warning');
            return;
        }

        try {
            submitBtn.disabled = true;
            btnText.style.display = 'none';
            btnLoader.style.display = 'flex';

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'register',
                    username: username,
                    whatsapp_number: whatsapp,
                    password: password,
                    registrationCode: registrationCode
                })
            });

            const result = await response.json();
            
            if (result.status === 'success') {
                showAlert && showAlert('Registration successful! Welcome to NayaRasta!', 'success');
                setTimeout(closeForm, 1500);
            } else {
                showAlert && showAlert(result.message || 'Registration failed', 'danger');
            }
        } catch (error) {
            console.error('Registration error:', error);
            showAlert && showAlert('Connection error. Please try again.', 'danger');
        } finally {
            submitBtn.disabled = false;
            btnText.style.display = 'inline';
            btnLoader.style.display = 'none';
        }
    });
}
// Show login error
function showLoginError(message) {
    const errorDiv = document.getElementById('login-error');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

// Handle logout - Updated version
async function handleLogout() {
    try {
        // Call logout.php to clear PHP session
        await fetch('logout.php');
    } catch (error) {
        console.error('Logout error:', error);
    } finally {
        // Clear JavaScript session storage
        currentUser = null;
        sessionStorage.removeItem('currentUser');
        showLandingPage();
    }
}

// Initialize app when script loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}