// MDCAT Online MCQs - Navigation and UI Components

// Generate navigation based on user role
function generateNavigation() {
    const navButtons = document.getElementById('nav-buttons');
    if (!navButtons || !currentUser) return;
    
    navButtons.innerHTML = '';
    
    const navItems = [
        { text: 'Dashboard', action: 'showDashboard', icon: 'fas fa-tachometer-alt' },
        { text: 'Take Test', action: 'showTestSelection', icon: 'fas fa-play-circle' },
        { text: 'My Results', action: 'showMyResults', icon: 'fas fa-chart-line' },
        { text: 'Notes', link: 'notes.html', icon: 'fas fa-sticky-note' },
        { text: 'Study Feed', link: '../studyfeed.html', icon: 'fas fa-comments' },
        { text: 'Manzil Ai', link: '../ai/ask.html', icon: 'fas fa-mobile-alt' }
    ];
    
    // Add admin-only items
    if (currentUser.role === 'admin') {
        navItems.push(
            { text: 'Manage Users', action: 'showUserManagement', icon: 'fas fa-users' },
            { text: 'Manage MCQs', action: 'showMCQManagement', icon: 'fas fa-question-circle' },
            { text: 'All Results', action: 'showAllResults', icon: 'fas fa-list-alt' },
            { text: 'Manage Codes', action: 'showCodeManagement', icon: 'fas fa-key' }
        );
    }
    
    navItems.forEach(item => {
        const li = document.createElement('li');
        li.className = 'nav-item';
        
        if (item.link) {
            // Handle external links
            li.innerHTML = `
                <a class="nav-link pointer" onclick="window.open('${item.link}', '_blank')">
                    <i class="${item.icon} me-1"></i>${item.text}
                </a>
            `;
        } else if (item.action) {
            // Handle internal actions
            li.innerHTML = `
                <a class="nav-link pointer" onclick="${item.action}()">
                    <i class="${item.icon} me-1"></i>${item.text}
                </a>
            `;
        }
        
        navButtons.appendChild(li);
    });
}

// NEW FUNCTION: Show Notes
function showNotes() {
    // Check if user is logged in
    if (!currentUser) {
        showAlert('Please login to access notes.', 'warning');
        return;
    }
    
    // Redirect to notes page
    window.open('notes.html', '_blank');
}


// NEW FUNCTION: Show Chat Admin (Admin only)
function showChatAdmin() {
    // Check if user is admin
    if (!currentUser || currentUser.role !== 'admin') {
        showAlert('Access denied. Admin privileges required.', 'danger');
        return;
    }
    
    // Redirect to chat admin page
    window.open('admin_chat.php', '_blank');
}

// Show dashboard
function showDashboard() {
    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="dashboard-card card h-100 text-center p-4">
                    <div class="dashboard-icon primary">
                        <i class="fas fa-play-circle"></i>
                    </div>
                    <h5>Take Test</h5>
                    <p class="text-muted">Start a new MCQ test</p>
                    <button class="btn btn-primary" onclick="showTestSelection()">Start Test</button>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="dashboard-card card h-100 text-center p-4">
                    <div class="dashboard-icon success">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h5>My Results</h5>
                    <p class="text-muted">View your test history</p>
                    <button class="btn btn-success" onclick="showMyResults()">View Results</button>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="dashboard-card card h-100 text-center p-4">
                    <div class="dashboard-icon notes">
                        <i class="fas fa-sticky-note"></i>
                    </div>
                    <h5>Study Notes</h5>
                    <p class="text-muted">Access your study materials</p>
                    <button class="btn btn-notes" onclick="showNotes()">View Notes</button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="dashboard-card card h-100 text-center p-4">
                    <div class="dashboard-icon info">
                        <i class="fas fa-comments"></i>
                    </div>
                    <h5>Study Feed</h5>
                    <p class="text-muted">Connect with fellow students</p>
                    <button class="btn btn-info" onclick="window.open('../studyfeed.html', '_blank')">Join Discussion</button>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="dashboard-card card h-100 text-center p-4">
                    <div class="dashboard-icon warning">
                        <i class="fas fa-user"></i>
                    </div>
                    <h5>Profile</h5>
                    <p class="text-muted">Manage your account</p>
                    <button class="btn btn-warning" onclick="showProfile()">View Profile</button>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="dashboard-card card h-100 text-center p-4">
                    <div class="dashboard-icon mobile">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h5>Manzil Ai</h5>
                    <p class="text-muted">Feel Free to ask any question</p>
                    <button class="btn btn-mobile" onclick="window.open('../ai/ask.html', '_blank')">Chat with Manzil</button>
                </div>
            </div>
                    <div class="row">
            <div class="col-md-4 mb-4">
                <div class="dashboard-card card h-100 text-center p-4">
                    <div class="dashboard-icon mobile">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h5>Mobile App</h5>
                    <p class="text-muted">Download our mobile app</p>
                    <button class="btn btn-mobile" onclick="window.open('../app.php', '_blank')">Get App</button>
                </div>
            </div>
        </div>
    `;
}

// Show profile
function showProfile() {
    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = `
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-user me-2"></i>Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Username:</label>
                            <input type="text" class="form-control" value="${currentUser.username}" disabled>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Role:</label>
                            <input type="text" class="form-control" value="${currentUser.role}" disabled>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Fee Status:</label>
                            <span class="badge ${currentUser.feePaid ? 'bg-success' : 'bg-warning'}">
                                ${currentUser.feePaid ? 'Paid' : 'Pending'}
                            </span>
                        </div>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Contact <strong>03328335332</strong> for profile updates or fee payment.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

//start from here
// Show my results
// async function showMyResults() {
//     if (!currentUser) return;
    
//     try {
//         showLoading(true);
        
//         const response = await fetch(`results.php?username=${encodeURIComponent(currentUser.username)}`);
//         const result = await response.json();
        
//         if (result.status === 'success') {
//             displayMyResults(result.data);
//         } else {
//             showAlert('Failed to load results.', 'danger');
//         }
//     } catch (error) {
//         console.error('Error loading results:', error);
//         showAlert('Failed to load results.', 'danger');
//     } finally {
//         showLoading(false);
//     }
// }

async function showMyResults() {
    if (!currentUser) return;
    
    try {
        showLoading(true);
        
        const response = await fetch(`results.php?username=${encodeURIComponent(currentUser.username)}`);
        const result = await response.json();
        
        if (result.status === 'success') {
            studentResultsData = result.data || [];
            calculateRankAndAverage();
            displayEnhancedResults();
        } else {
            showAlert('Failed to load results.', 'danger');
        }
    } catch (error) {
        console.error('Error loading results:', error);
        showAlert('Failed to load results.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Display my results
function displayMyResults(results) {
    const contentArea = document.getElementById('content-area');
    
    if (results.length === 0) {
        contentArea.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <h2 class="mb-4"><i class="fas fa-chart-line me-2"></i>My Results</h2>
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-chart-line fa-3x text-muted mb-3"></i>
                            <h5>No Results Yet</h5>
                            <p class="text-muted">You haven't taken any tests yet. Start your first test!</p>
                            <button class="btn btn-primary" onclick="showTestSelection()">
                                <i class="fas fa-play me-2"></i>Take Test
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        return;
    }
    
    let html = `
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-chart-line me-2"></i>My Results</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-list me-2"></i>Test History</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Test #</th>
                                        <th>Score</th>
                                        <th>Percentage</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
    `;
    
    results.forEach((result, index) => {
        const percentage = Math.round((result.score / result.total) * 100);
        const statusClass = percentage >= 70 ? 'success' : percentage >= 50 ? 'warning' : 'danger';
        
        html += `
            <tr>
                <td><strong>#${results.length - index}</strong></td>
                <td>${result.score} / ${result.total}</td>
                <td>
                    <span class="badge bg-${statusClass}">${percentage}%</span>
                </td>
                <td>${new Date(result.date).toLocaleDateString()}</td>
                <td>
                    <button class="btn btn-sm btn-outline-info" onclick="downloadResultPDF(${result.id})">
                        <i class="fas fa-download me-1"></i>PDF
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += `
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    contentArea.innerHTML = html;
}

// Download result PDF
async function downloadResultPDF(resultId) {
    try {
        showLoading(true);
        
        const response = await fetch(`results.php?action=download_pdf&result_id=${resultId}`);
        const result = await response.json();
        
        if (result.status === 'success') {
            // Create download link
            const blob = new Blob([atob(result.data.content)], { type: 'application/pdf' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = result.data.filename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } else {
            showAlert('Failed to generate PDF.', 'danger');
        }
    } catch (error) {
        console.error('Error downloading PDF:', error);
        showAlert('Failed to download PDF.', 'danger');
    } finally {
        showLoading(false);
    }
}